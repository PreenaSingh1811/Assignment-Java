package com.yash.spring;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

class EvenNumber extends Object {

	public int evenNumber(ArrayList<Integer> arr) {

		int len = arr.size();
		int count = 0;
		int numofPair = 0;
		int i;
		ArrayList<Integer> num = new ArrayList<Integer>();
		ArrayList<Integer> templist = new ArrayList<Integer>();
		HashMap<Integer, List<Integer>> h = new HashMap<Integer, List<Integer>>();

		for (i = 0; i < len; i++) {
			for (int j = i; j < len; j++) {
				if (arr.get(j) % 2 == 0) {
					num.add(arr.get(j));
					count++;
				} else {
					if (i == j) {
						i = j;
					} else if (j > i) {
						i = j - 1;
					}
					break;
				}
			}
			templist = new ArrayList<>(num);
			if (count <= 2) {

				num.removeAll(templist);
			}
			if (count > 2) {
				numofPair++;

				h.put(count, templist);

			}
			count = 0;

		}

		System.out.println(h);
		return numofPair;
	}

	public static void main(String[] args) {
		ArrayList<Integer> num = new ArrayList<Integer>();
		/*
		 * num.add(1); num.add(2); num.add(3); num.add(2); num.add(4); num.add(6);
		 * num.add(8); num.add(5); num.add(7); num.add(12); num.add(8); num.add(4);
		 * num.add(16); num.add(18); num.add(5); num.add(8); num.add(4); num.add(2);
		 * num.add(1); num.add(2);
		 */
		num.add(4);
		EvenNumber e = new EvenNumber();
		// System.out.println(e.evenNumber(num));
		/*
		 * HashMap<A, String> has=new HashMap<A, String>(); A a=new A(); A a1=new A();
		 * a.setA(101); a.setMsg("A"); a1.setA(101); a1.setMsg("A"); has.put(a, "A");
		 * has.put(a1,"B"); System.out.println(has.get(a)); a.setA(102);
		 * a.setMsg("ASDF");
		 * 
		 * System.out.println(has.get(a)); System.out.println(has);
		 */
EvenNumber b=new EvenNumber();
//b.a(0, 0);
	}

	public void a(long a, int d) {
		System.out.println("Hello");
	}

	public void a(int d, long b) {
		System.out.println("Hi");
	}

}
