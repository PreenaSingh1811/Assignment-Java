package com.yash.spring;

public class B{
	int b;
	private String msg;
	public  B () {
		
	}

	public B(int b, String msg) {
		System.out.println(" B class 2 args");
		this.b = b;
		this.msg = msg;

	}
	
	
	public void show() {
		System.out.println("B.show()");
		System.out.println(b);
		System.out.println(msg);
	}
}
