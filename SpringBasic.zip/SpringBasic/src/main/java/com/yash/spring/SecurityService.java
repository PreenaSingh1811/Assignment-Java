package com.yash.spring;

import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;

@Aspect
public class SecurityService {
	
	@Pointcut(value="execution (* com.yash.spring.AccountService.my*(..))")
	public void method1() {
		
	}
	@Pointcut(value="execution (* com.yash.spring.CustomerService.up*(..))")
	public void method2() {
		
	}
	@Before(value= "method1()")
	public void verifyUser() {
		System.out.println("Security Service verifyUser");
	}


}
