package com.yash.spring;

public class AccountService {
	
	public void getBalance() {
		System.out.println("GetBalance()Begin");
		System.out.println("GetBalance End");
		System.out.println("GetBalance Done");
	}
	public void myDeposits() {
		System.out.println("AccountService.myDeposits() Begin");
		System.out.println("AccountService.myDeposits() End");
		System.out.println("AccountService.myDeposits() Done");
	}
	public void withdraw()throws RuntimeException {
		System.out.println("AccountService.enclosing_method() Begin");
		
		if(1==1) {
			throw new InSufficientFundException();
		}
		System.out.println("AccountService.withdraw()  End");
	}
	
	

}
