package com.yash.spring;

import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;


@Aspect
public class LogService {
	
	@Pointcut(value="execution(* com.yash.spring.AccountService.my*(..))")
	public void method1() {
		
	}
	@Pointcut(value="execution(* com.yash.spring.CustomerService.up*(..))")
	public void method2() {
		
	}
	@Before("method1() or method2()")
	public void logBefore() {
		System.out.println("LogService logBefore()");
	}
	@AfterReturning("method1()")
	public void logReturning() {
		System.out.println("LogReturning()");
	}

	@After("method1()")
	public void lofAfter() {
		System.out.println("Log After()");
	}
}
