package com.yash.spring;

public interface Int1 {
static String show() {
	return "";
}
}
