package com.yash.spring;

public class Hello2 {
	X x;

	public Hello2(){
		System.out.println("Hello const");
	}
	public void setX(X x) {
		this.x = x;
	}
	

}
