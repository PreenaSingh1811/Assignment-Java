package com.yash.spring;

public class Hello {
	private A a;
	private B b;
	private X x;
	
	public Hello( B bObj) {
		System.out.println("Hello 1 arg");
		this.b=bObj;
	}
	public  void setAobj(A aObj) {
		System.out.println("Hello 2 args");
		this.a=aObj;
		
	}
	public void show() {
		System.out.println("Hello.show()");
		a.show();
		b.show();
	}
	

}
