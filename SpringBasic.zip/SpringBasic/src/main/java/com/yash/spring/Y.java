package com.yash.spring;

public class Y extends X {
	public Y() {
		System.out.println("Y constructorS");
	}

}
