package com.yash.spring;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainApp {
	public static void main(String[] args) {
		//ApplicationContext context = new ClassPathXmlApplicationContext("application-context.xml");
		ApplicationContext context = new ClassPathXmlApplicationContext("app-context.xml");
		/* Hello h = (Hello) context.getBean("hello"); */
		Hello2 h = (Hello2) context.getBean("hello2");
		//h.show();
	}
}
