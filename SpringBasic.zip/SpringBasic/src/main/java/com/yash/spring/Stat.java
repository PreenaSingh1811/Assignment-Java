/*
 * package com.yash.spring;
 * 
 * public class Stat {
 * 
 * public static void main(String[] args) { { System.out.println("Hello"); }
 * System.out.println(p()); long[] a1= {3,4,5}; long[] a2= p(a1); } public
 * static String p(long a[]) { try { System.out.println("AAA"); return "a";
 * }finally { System.out.println("ASDF"); return "sd"; }
 * 
 * } }
 */