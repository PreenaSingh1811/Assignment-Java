package com.yash.spring;

interface I{
	Object  add(int a, int b);
}
public class MethodR {
	static String arun(int x, int y) {
		return null;
	}
	public static void main(String[] args) {
		I i = MethodR::arun;
	}

}
