package com.yash.spring;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class AopConfiguration {

	@Bean
	public AccountService accountService() {
		return new AccountService();
	}

	@Bean
	public CustomerService customerService() {
		return new CustomerServiceImpl();
	}

}
