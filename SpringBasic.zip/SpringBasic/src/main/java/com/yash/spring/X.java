package com.yash.spring;

public class X {
	
	
	int x;
	public X() {
		System.out.println("X constructor");
	}
	
	public void m1(String a) {
		
		System.out.println("Inside String m1");
	}
	public void m1(int a) {
		System.out.println("Inside Int m2");
	}
}
