package com.yash.spring;

public interface Int2 {
public void show();
}
