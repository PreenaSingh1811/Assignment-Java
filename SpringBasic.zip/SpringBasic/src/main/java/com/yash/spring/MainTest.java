/*
 * package com.yash.spring;
 * 
 * import
 * org.springframework.context.annotation.AnnotationConfigApplicationContext;
 * 
 * public class MainTest implements Int1,Int2{ public static void main(String
 * args[]) { AnnotationConfigApplicationContext ctx= new
 * AnnotationConfigApplicationContext(AOPConfiguraton.class); CustomerService
 * customerService =(CustomerService) ctx.getBean("customerService");
 * 
 * System.out.println("==================="); // customerService.addCustomer();
 * customerService.updateCustomer(); AccountService accountService =new
 * AccountService(); accountService.myDeposits();
 * 
 * try { accountService.withdraw(); }catch(RuntimeException e) {
 * System.out.println("Inside Catch"); }
 * 
 * }
 * 
 * int m1(int a,int b) { return 0; } int m2(float a, float b) { return 0; }
 * 
 * 
 * 
 * 
 * 
 * }
 */