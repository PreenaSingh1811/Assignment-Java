package com.yash.spring;

public class InSufficientFundException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	


}
