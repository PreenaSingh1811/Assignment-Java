package com.yash.spring;

public interface CustomerService {
	
	public void addCustomer();
	public void updateCustomer();

}
