package com.yash.assignment.Assignment3;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class SmallestAndLargestWord {
	
	
	public String toFndSmallestNLargest(String str) {
		String[] commaSeparatedArr = str.split("\\s* \\s*");
		
			List<String > longestWords=	Arrays.stream(commaSeparatedArr)
			         .collect(Collectors.groupingBy(String::length)).entrySet()
			         .stream()
			         .sorted(Map.Entry.<Integer, List<String>> comparingByKey().reversed())
			         .map(Map.Entry::getValue).findFirst().orElse(null);
			
			List<String > smallest=	Arrays.stream(commaSeparatedArr)
			         .collect(Collectors.groupingBy(String::length)).entrySet()
			         .stream()
			         .sorted(Map.Entry.<Integer, List<String>> comparingByKey())
			         .map(Map.Entry::getValue).findFirst().orElse(null);
			
			return "Smallest :- "+smallest+"\n"+"Longest :-"+longestWords;
		
	}
	public static void main(String[] args) {
		SmallestAndLargestWord s=new SmallestAndLargestWord();
		System.out.println(s.toFndSmallestNLargest("the length of the longest "));
	}

}
