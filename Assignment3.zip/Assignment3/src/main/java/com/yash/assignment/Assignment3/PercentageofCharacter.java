package com.yash.assignment.Assignment3;

public class PercentageofCharacter {
	
	public String tofindPercentageofcharacters(String str) {
		long len=str.length();
		
		long upperCase=	str.chars().mapToObj(i -> (char) i)
				.filter(c ->Character.isUpperCase(c)).count();
		long lowerCase=	str.chars().mapToObj(i -> (char) i)
				.filter(c ->Character.isLowerCase(c)).count();
		long digit=	str.chars().mapToObj(i -> (char) i)
				.filter(c ->Character.isDigit(c)).count();
		/**/
		return "Upper Case Percent:- "+(upperCase*100)/len+"\n"
				+"Lower Case Percent:-"+(lowerCase*100)/len+"\n"
				+"Digit Percent:-"+(digit*100)/len;
				
				
				
	}
	public static void main(String[] args) {
		PercentageofCharacter p=new PercentageofCharacter();
		System.out.println(p.tofindPercentageofcharacters("HelloToNewWorld12345"));
	}

}
