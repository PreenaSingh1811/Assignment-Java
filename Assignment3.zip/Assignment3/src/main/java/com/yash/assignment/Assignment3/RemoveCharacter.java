package com.yash.assignment.Assignment3;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class RemoveCharacter {

	public String toRemoveCommonCharacter(String str1,String str2) {
		List<Character> char1=(str1.toLowerCase()).chars().mapToObj(e->(char)e).collect(Collectors.toList());
		List<Character> char2=(str2.toLowerCase()).chars().mapToObj(e->(char)e).collect(Collectors.toList());
		List<Character> temp=new ArrayList<Character>();
		temp.addAll(char1);
		char1.removeAll(char2);
		char2.removeAll(temp);
		return char1.toString() +"    "+char2.toString();
	}
	public static void main(String[] args) {
		RemoveCharacter r=new RemoveCharacter();
		System.out.println(r.toRemoveCommonCharacter("abc@d", "cd@fe"));
	}
}
