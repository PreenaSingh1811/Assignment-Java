package com.yash.assignment.Assignment3;

public class Vowels {


	public void capatalizeVowelsinString(String str) {
		str.toLowerCase().chars().mapToObj(i -> (char) i)
				.map(c -> "aeiou".contains(String.valueOf(c))?c.toString().toUpperCase():c)
				.forEach(c->System.out.print(c));
	}


	public static void main(String[] args) {
		Vowels v=new Vowels();
		v.capatalizeVowelsinString("hello");
	}
}
