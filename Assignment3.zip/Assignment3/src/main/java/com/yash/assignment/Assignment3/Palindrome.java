package com.yash.assignment.Assignment3;

import java.util.ArrayList;
import java.util.List;

public class Palindrome {
	
	public List<Integer> toFindPallindrome(){
		List<Integer> palindromeList=new ArrayList<Integer>();
		int x=1,sum=0,r;
		while(x<=1000) {
			int num=x; 
			sum=0;
			  while(num>0){    
				   r=num%10; 
				   sum=(sum*10)+r;    
				   num=num/10;    
				  } 
			  if(x==sum)  {  
				  palindromeList.add(x);
			  }
			 x++;
		}
		return palindromeList;
	}
public static void main(String[] args) {
	Palindrome p=new Palindrome();
	System.out.println(p.toFindPallindrome());
}
}
