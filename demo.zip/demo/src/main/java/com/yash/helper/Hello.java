package com.yash.helper;

public class Hello {
	public static void main(String[] args) {
System.out.println(new String("Hello").equals("Hello"));
	//	s=null;
	//	//System.gc();
		//System.out.println("Hello in main");
		
		
		
		try {
			throw new Exception();
		}catch(MyException me) {
			System.out.println("Hi");
		}catch (Exception e) {
			System.out.println("Hello");
		}
	}
	/*
	 * @Override protected void finalize() throws Throwable {
	 * System.out.println("hello in finalize"); }
	 */
}

