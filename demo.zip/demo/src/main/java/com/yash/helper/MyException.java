package com.yash.helper;

public class MyException extends Exception {

}
