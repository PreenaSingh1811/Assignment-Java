package com.yash.assignment.Assignment;

public class CapitalizeLetters {
	

	 int a=200;
	public static String returnCapitalizedLetterString(String sentence) {

		StringBuilder result = new StringBuilder(sentence.length());
		String words[] = sentence.split("\\ "); 
		
		for (int i = 0; i < words.length; i++)
		{			
			result.append(Character.toUpperCase(words[i].charAt(0)))
			.append(words[i].substring(1,words[i].length()-1))
			.append(Character.toUpperCase(words[i].charAt(words[i].length()-1))).append(" ");

		}
		return result.toString().trim();
	}
	public static void main(String[] args) {
		 CapitalizeLetters c=new B();
		 c.m1();
		 System.out.println(c.a);
		 CapitalizeLetters b=new CapitalizeLetters();
		 b.m1();
		 System.out.println(b.a);
	 }
	public void m1() {
		a=a+200;
	}
	/*
	 * public static void main(String[] args) {
	 * 
	 * }
	 */


}
class B extends CapitalizeLetters{
	int a=2000;
	
	public void m1() {
		a=a+400;
	}
}
 class main{
	 
}

