package com.yash.assignment.Assignment;

import java.io.IOException;

public class SpyNumber {

	public static boolean checkSpyNumber( int digit) {
double a=10.9;
a++;
System.out.println(0.0/0);
		int prod=1,sum=0,rem;
		
		String s1 = "Yash";
		String s2 = "Technology";
		s1.concat(s2);

		while(digit!=0) {
			rem = digit % 10;
			prod = prod * rem;
			sum = sum + rem;
			digit = digit / 10;
		}
		if(sum==prod) {
			return true;
		}else {
			return false;
		}
	}
	void check() throws Exception{
		
		try {
			throw new IOException();
		}catch (IOException e) {
			System.out.println("Catc 2");
			throw new Exception();
		}catch (Exception e) {
			System.out.println("Catch 3");
		}finally {
			System.out.println("Inside Finally");
		}
		
		
	}
	public static void main(String[] args) {
//		SpyNumber a=new SpyNumber();
//		a.checkSpyNumber(9);
//		int i=0;
//		i=i++;
//		System.out.println(i);
//		i=++i;
//		System.out.println(i);
//		String s1=new String("Yash");
//		String s2="Yash";
//		System.out.println(s1==s2);
//		 s1=s1.intern();
//		System.out.println(s2==s1);
//		String a1="Yash"+"t";
//		String a2="Yash".concat("t");
//		String a3="Yasht";
//		System.out.println(a2==a1);
//		System.out.println(a1.equalsIgnoreCase(a2));
//		System.out.println(a1==a3);
		String a="Yash";
		String b="Tech";
		String s1 = a+b;
		String s2 = "Yash".concat("Tech");
		String s3 = "YashTech";
		
		
		System.out.println(s1 == s2);
		System.out.println(s1 == s3);
		System.out.println(s2==s3);
		System.out.println(s1.equals(s2));
		
		/*
		 * try { a.check(); }catch (Exception e) { System.out.println("Inside main"); }
		 */
	}
}
