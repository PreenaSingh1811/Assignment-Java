package com.yash.assignment.exception;

public class SubListException extends RuntimeException {

	public SubListException(String msg) {
		super(msg);
		
	}
	

}
