package com.yash.assignment.Assignment;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class HackerRank {

	public static void main(String[] args) {
		List<Integer> lst = new ArrayList<Integer>();
		
		  lst.add(10); lst.add(20); lst.add(5); lst.add(30); lst.add(4); lst.add(20);
		  lst.add(50); lst.add(0); lst.add(60);
		 
		
		/*
		 * lst.add(10); lst.add(8); lst.add(4); lst.add(30);
		 */
		updateList(lst);
	}

	public static void updateList(List<Integer> l) {
		
		
		  List<Integer> l1 =new ArrayList<Integer>(); 
		  Set<Integer> set=new HashSet<Integer>(l);
		  l1.add(l.get(0));
		  
		  for(int i = 1; i < set.size() - 2; i++) { 
			  for(int j = 1; j < set.size() - 2; j++) 
			  if(l.get(i)<l.get(j+1)) {
				  l1.add(j);
			  }else {
				  
			  }
		  
		  }
		  l1.add(l.get(l.size()-1));
		 System.out.println(l1);
		
		
		 /* for (int i = 1; i < l.size() - 2; i++) { for (int j = 1; j < l.size() - 2;
		  j++) { if (l.get(j + 1) < l.get(j)) { l.remove(j + 1); } else if (l.get(j +
		  1) == l.get(j)) { l.remove(j); } System.out.println(l); }
		  
		  }
		 */

		
	}

}
