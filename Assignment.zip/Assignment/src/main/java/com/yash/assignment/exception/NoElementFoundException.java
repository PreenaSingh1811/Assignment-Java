package com.yash.assignment.exception;

public class NoElementFoundException extends RuntimeException {

	public NoElementFoundException(String msg) {
		super(msg);
	
	}
	

}
