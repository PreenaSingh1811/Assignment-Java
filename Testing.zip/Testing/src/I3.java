@FunctionalInterface
public interface I3  extends I,I2{

}
