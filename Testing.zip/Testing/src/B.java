import java.io.FileNotFoundException;
import java.io.IOException;

public class B extends A{
	
	
	String m1() throws FileNotFoundException {
		return null;
		//throw new IOException();
		//return null;
	}
	

}
