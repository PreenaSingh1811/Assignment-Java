@FunctionalInterface
public interface I {
int m1();
}
