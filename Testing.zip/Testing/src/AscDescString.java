import java.util.Scanner;

public class AscDescString {
	public static void main(String args[]) {

		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the size of array");
		int arrySize = sc.nextInt();
		String[] array = new String[arrySize];
		System.out.println("Enter String in Array");
		for (int i = 0; i < arrySize; i++) {
			array[i] = sc.next();
		}

		int choice;
		do {

			System.out.println();
			System.out.println("Enter the choice");
			System.out.println("1. To delete element from array");
			System.out.println("2. To print array in ascending order");
			System.out.println("3. To print array in descending order");
			System.out.println("4. To update array at nth position");
			System.out.println("0. To terminate");

			choice = sc.nextInt();
			switch (choice) {

			case 1: {

				String word = sc.next();
				for (int i = 0; i < arrySize; i++) {
					if (array[i].equals(word)) {
						for (int j = i; j < arrySize - 1; j++) {
							array[j] = array[j + 1];
						}
						break;
					}

				}
				for (int i = 0; i < arrySize - 1; i++) {
					System.out.print(array[i] + " ");
				}
				break;
			}
			case 2: {
				System.out.println("Array in ascending order");
				for (int i = 0; i < arrySize - 1; i++) {
					for (int j = 0; j < arrySize - 2; j++) {
						if (array[j].compareToIgnoreCase(array[j + 1]) > 0) {
							String temp = array[j];
							array[j] = array[j + 1];
							array[j + 1] = temp;
						}
					}
				}
				for (int i = 0; i < arrySize - 1; i++) {
					System.out.print(array[i] + " ");
				}
				System.out.println("");
				break;
			}
			case 3: {
				System.out.println("Array in Descending order");
				for (int i = 0; i < arrySize - 1; i++) {
					for (int j = 0; j < arrySize - 2; j++) {
						if (array[j].compareToIgnoreCase(array[j + 1]) < 0) {
							String temp = array[j];
							array[j] = array[j + 1];
							array[j + 1] = temp;
						}
					}
				}
				for (int i = 0; i < arrySize - 1; i++) {
					System.out.print(array[i] + " ");
				}
				System.out.println();
				break;

			}
			case 4: {
				System.out.println("Enter the index to be updated");
				int index = sc.nextInt();
				System.out.println("Enter the string");
				String str = sc.next();
				array[index] = str;
				System.out.println("Updated Array");
				for (int i = 0; i < arrySize - 1; i++) {
					System.out.print(array[i] + " ");
				}
				break;

			}
			case 0:{
				break;
			}
			default: {
				System.out.println("Enter valid choice");
				break;
			}
			}
		} while (choice != 0);

	}
}
