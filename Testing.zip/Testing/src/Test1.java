/*
 * public class Test1 implements I,I2 { public static void main(String args[]) {
 * // System.out.println(a);
 * 
 * 
 * } public int m1() { return 10; }
 * 
 * }
 */
public class Test1{
	
	public static void main(String args[]) {
		
	}
}