
public interface I2 extends I{


}
