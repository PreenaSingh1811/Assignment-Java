import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;

public class Test {
	public static void main(String args[]) {
		/*
		 * Map<Employee,Integer> empMap= new HashMap<Employee, Integer>();
		 * empMap.put(new Employee(1, "Yash"), 1); Map<Employee,Integer> empTreeMap= new
		 * TreeMap<Employee, Integer>(); empTreeMap.put(new Employee(1, "name"), 2);
		 * empTreeMap.put(new Employee(2, "Yash"), 1);
		 * System.out.println(empTreeMap.get(new Employee(1,"name")));
		 * empTreeMap.forEach((k,v)->System.out.println(k+" "+v));
		 * //empTreeMap.put(null,1); Test t=new Test();
		 */
	//	t.m1(3,4);
		
		B a= new B();
		a.m1();
		
	}	
		/*int[] intArray = new int[]{ 4,6,7,8}; 
		for (int i=0;i<(intArray.length);i++) {
			
			if(intArray[i]==6) {
				try{
					throw new RuntimeException();
				}catch(Exception e) {
					System.out.println("Inside Runtime Exception");
				}
			}else {
				System.out.println("Print "+intArray[i]);
			}
			
		}
	
	}
	
	public void m1(int a,long b) {
		System.out.println("Float");
	}
	public void m1(long a,int b) {
		System.out.println("Double");
	}
*/
}
