
public class Employee implements Comparable<Employee>{
	int id;
	String name;
	public Employee(int no,String name) {
		this.name=name;
		this.id=no;
	}


	@Override
	public int compareTo(Employee o) {
		
		if(o.id>this.id)
	        return 1;
	    if(o.id==this.id)
	        return -1;
	    return 0;
	}
}
