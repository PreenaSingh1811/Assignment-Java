import java.io.FileNotFoundException;

public class A {
	/*
	 * A(){ System.out.println("A"); }A(int a){ this(); System.out.println("AA"); }
	 */
	
	String m1()  {
		System.out.println("Hi");
		return null;
	}
	
	
	public static void main(String[] args) {
		A a= new Cat();
		a.
	}
}
class Dog extends A{
	void sleep() {}
}
class Cat extends Dog{
	void meow() {}
}
