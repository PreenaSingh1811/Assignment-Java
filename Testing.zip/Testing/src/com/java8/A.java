package com.java8;

public class A implements CustomMarkerInterface{
	public void m1() {
		System.out.println("A.m1()");
	}

}
