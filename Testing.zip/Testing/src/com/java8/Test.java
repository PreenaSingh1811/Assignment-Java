package com.java8;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

public class Test {
	public static void main(String args[]) {
		List<Integer> listobj= Arrays.asList(1,2,3,4,2,2,7,8,9,10,11,12);
		
		Map<Object, Long> counts =
			    listobj.stream().collect(Collectors.groupingBy(e -> e, Collectors.counting()));
		
		System.out.println(counts);
	  Integer integer = listobj.stream().filter(i->i%2==0).map(i->i).reduce(Integer::sum).get();
		System.out.println(integer);
		/*for(Integer i:listobj) {
			System.out.println(i.toString().hashCode());
			m1((a,b)->i+3);
			
		}
		for(int i=0;i<listobj.size();i++) {
			//m1((a,b)->i+3);
		}
	}
	static void m1(I1 e){
		int ans=e.add(0, 0);
		//System.out.println(ans);
		 * 
		*/
		//HashMap<Integer> 
	}
	
	
	int factorial(int n) {
		
		
		return 0;
	}

}
