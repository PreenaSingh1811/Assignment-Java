package com.java8;

public interface CustomMarkerInterface {

}
