package com.java8;

import com.java8.A;

public class B{

//	 public int m() {
//		 A a=new A();
//		a.m1();
//		 return 0;
//	 }

	public void m2() {
		System.out.println("B.m2()");
	}

//	public static void main(String[] args) {
//		B b = new B();
//		System.out.println(b.m());
//	}
}
