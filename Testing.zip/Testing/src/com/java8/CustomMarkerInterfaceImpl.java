package com.java8;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

public class CustomMarkerInterfaceImpl {
	static String className;

	public static void main(String[] args)
			throws ClassNotFoundException, InstantiationException, IllegalAccessException, IllegalArgumentException,
			InvocationTargetException, NoSuchMethodException, SecurityException {
		System.out.println("Start of main");
		className = args[0];
		Class<?> clz = Class.forName(className);
		A obj = (A) clz.newInstance();

		if (obj instanceof CustomMarkerInterface) {

			Method[] methods = clz.getDeclaredMethods();
			for (Method method : methods) {
				System.out.println(method.getName());
				method.invoke(obj);
			}
		}
		System.out.println("end of main");
	}
}
