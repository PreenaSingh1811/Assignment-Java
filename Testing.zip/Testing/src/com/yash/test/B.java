package com.yash.test;

import com.java8.A;

public class B extends A {
	
protected void m1() {
	super.m1();
		System.out.println("B.m1()");
	}

	 public int m() {
		 A a=new A();
		m1();
		 return 0;
	 }
	 
	 
	 
	 public static void main(String[] args) {
		B b= new B();
		System.out.println(b.m());
	}
}
