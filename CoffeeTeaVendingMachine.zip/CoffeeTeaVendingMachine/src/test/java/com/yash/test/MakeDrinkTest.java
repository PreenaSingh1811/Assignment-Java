package com.yash.test;

import static org.mockito.Mockito.times;

import java.io.OutputStream;

import org.apache.log4j.Appender;
import org.apache.log4j.Logger;
import org.apache.log4j.spi.LoggingEvent;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import com.yash.drinks.Drinks;
import com.yash.machinecontainers.CoffeeContainer;
import com.yash.machinecontainers.MilkContainer;
import com.yash.machinecontainers.SugarContainer;
import com.yash.machinecontainers.TeaContainer;
import com.yash.machinecontainers.WaterContainer;
import com.yash.resources.VendingMachineOperationnImpl;
import com.yash.services.ScannerInput;

@RunWith(value = MockitoJUnitRunner.class)
public class MakeDrinkTest {

	@InjectMocks
	private VendingMachineOperationnImpl vendingMachineOperationnImpl;

	@Mock
	private Appender appenderMock;

	@Captor
	private ArgumentCaptor<LoggingEvent> captor;

	

	@Mock
	TeaContainer teaContainer;
	@Mock
	MilkContainer milkContainer;
	@Mock
	WaterContainer waterContainer;
	@Mock
	SugarContainer sugarContainer;
	@Mock
	CoffeeContainer coffeeContainer;
	@Mock
	Drinks drink;

	@Mock
	OutputStream os;

	@Mock
	ScannerInput sc;

	@Before
	public void setupAppender() {

		appenderMock = Mockito.mock(Appender.class);
		Logger.getRootLogger().addAppender(appenderMock);
	}

	@After
	public void removeAppender() {
		Logger.getRootLogger().removeAppender(appenderMock);
	}

	@Test
	public void shouldReturnDefalultQuantityOfTeaWhenTeaIsOrder() {
		Mockito.when(sc.nextInt()).thenReturn(1,0);
		vendingMachineOperationnImpl.makeDrink(1, "Tea");
		Mockito.verify(appenderMock, times(1)).doAppend(captor.capture());
	}

	@Test
	public void shouldReturnDefalultQuantityOfTeaWhenCoffeeIsOrder() {
		Mockito.when(sc.nextInt()).thenReturn(2,0);
		vendingMachineOperationnImpl.makeDrink(2, "Coffee");
		Mockito.verify(appenderMock, times(1)).doAppend(captor.capture());
	}

	@Test
	public void shouldNotMakeDrinkIfContainerHasInsufficientAmount() {
		 Mockito.when(sc.nextInt()).thenReturn(2);
		vendingMachineOperationnImpl.makeDrink(10000, "Coffee");
		Mockito.verify(appenderMock, times(2)).doAppend(captor.capture());
	}

	@Test
	public void shouldResetValueToMaxCapacityOftheContainer() {
		vendingMachineOperationnImpl.resetContainer();
		Mockito.verify(appenderMock, times(1)).doAppend(captor.capture());
	}

	@Test
	public void shouldReturnTheMaxCapacityofContainerAndCurrentCapacity() {
		vendingMachineOperationnImpl.containerStatus();
		Mockito.verify(appenderMock, times(12)).doAppend(captor.capture());
	}

	@Test
	public void shouldReturnTotalSalesOftheDrink() {
		vendingMachineOperationnImpl.totalSaleCalculator();
		Mockito.verify(appenderMock, times(19)).doAppend(captor.capture());
	}

	@Test
	public void shouldRifillTheContainerIftheContainerIsEmpty() {
		Mockito.when(sc.nextInt()).thenReturn(2,0);
		vendingMachineOperationnImpl.makeDrink(50, "Tea");
		vendingMachineOperationnImpl.refillContainer(true);
		Mockito.verify(appenderMock, times(10)).doAppend(captor.capture());
	}

	@Test
	public void shouldRifillTheContainerIftheContainerIsEmptyAndContinueOptionSeleted() {
		vendingMachineOperationnImpl.refillContainer(true);
		Mockito.verify(appenderMock, times(8)).doAppend(captor.capture());
	}

	@Test
	public void shouldNotRifillContainerIsGivenWrong() {
		vendingMachineOperationnImpl.refillContainer(true);
		Mockito.verify(appenderMock, times(8)).doAppend(captor.capture());
	}

	@Test
	public void shouldNotRifillContainerIsGivenWrongLessthan1() {
		vendingMachineOperationnImpl.refillContainer(true);
		Mockito.verify(appenderMock, times(8)).doAppend(captor.capture());
	}

	//-----------------------------------------------------------------------------------------------------------	

	
}
