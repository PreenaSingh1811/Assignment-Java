package com.yash.test;

import static org.mockito.ArgumentMatchers.anyObject;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import org.apache.log4j.Appender;
import org.apache.log4j.Logger;
import org.apache.log4j.spi.LoggingEvent;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import com.yash.services.MakeDrinkServices;
import com.yash.services.ScannerInput;

@RunWith(value = MockitoJUnitRunner.class)
public class MakeDrinkServicesTest {

	@InjectMocks
	private MakeDrinkServices makeDrinkObject;
	@Captor
	private ArgumentCaptor<LoggingEvent> captor;

	
	@Mock
	private Appender appenderMock;
	@Mock
	ScannerInput sc;

	@Before
	public void setupAppender() {

		appenderMock = Mockito.mock(Appender.class);
		Logger.getRootLogger().addAppender(appenderMock);
	}

	@After
	public void removeAppender() {

		Logger.getRootLogger().removeAppender(appenderMock);
	}

	@Test
	public void shouldPerformMakeDrinkOperationWhenCaseOneAndFiveCupsProvided() {
		Mockito.when(sc.nextInt()).thenReturn(1, 5, 0, 0);
		makeDrinkObject.menuList();
		verify(appenderMock, times(3)).doAppend(captor.capture());
	}

	@Test
	public void shouldPerformMakeDrinkOperationWhenCaseTwoAndFiveCupsProvided() {
		Mockito.when(sc.nextInt()).thenReturn(2, 5, 0, 0);
		makeDrinkObject.menuList();
		verify(appenderMock, times(3)).doAppend(captor.capture());
	}

	@Test
	public void shouldPerformMakeDrinkOperationWhenCaseThreeAndFiveCupsProvided() {
		Mockito.when(sc.nextInt()).thenReturn(3, 5, 0, 0);
		makeDrinkObject.menuList();
		verify(appenderMock, times(3)).doAppend(captor.capture());
	}

	@Test
	public void shouldPerformMakeDrinkOperationWhenCaseFourAndFiveCupsProvided() {
		Mockito.when(sc.nextInt()).thenReturn(4, 5, 0, 0);
		makeDrinkObject.menuList();
		verify(appenderMock, times(3)).doAppend(captor.capture());
	}

	@Test
	public void shouldcalculateTotalsaleWhenCaseSixSelected() {
		Mockito.when(sc.nextInt()).thenReturn(6, 0);
		makeDrinkObject.menuList();
		verify(appenderMock, times(21)).doAppend((LoggingEvent) anyObject());
	}

	@Test
	public void shouldPerformResetOptionEightIsSelected() {
		Mockito.when(sc.nextInt()).thenReturn(8, 0);
		makeDrinkObject.menuList();
		verify(appenderMock, times(3)).doAppend(captor.capture());

	}

	@Test
	public void shouldReturnstatusOfContainerIfSevenIsSelected() {
		Mockito.when(sc.nextInt()).thenReturn(7, 0);
		makeDrinkObject.menuList();
		verify(appenderMock, times(14)).doAppend(captor.capture());
	}

	@Test
	public void shouldReturnstatusOfContainerInvalidOptionisgiven() {
		Mockito.when(sc.nextInt()).thenReturn(11, 0);
		makeDrinkObject.menuList();
		verify(appenderMock, times(3)).doAppend(captor.capture());
	}

	@Test
	public void shouldRefillTheContainer() {
		Mockito.when(sc.nextInt()).thenReturn(5, 1, 20, 0, 0, 0, 0);
		makeDrinkObject.menuList();
		verify(appenderMock, times(12)).doAppend(captor.capture());
	}

//    @Test
//	public void shouldPerformMakeDrinkOperationWhenCaseOneAndFiveCupsProvided()
//	{
//    	makeDrinkObject.menuList();		
//		verify(appenderMock,times(1)).doAppend((LoggingEvent) anyObject());
//	}
//    
	@Test
	public void shouldPerformRefill() {

		makeDrinkObject.menuList();
		verify(appenderMock, times(2)).doAppend(captor.capture());
	}

}
