package com.yash.machinecontainers;

public class CoffeeContainer implements Container {

	private int coffeeContainerCapacity = 2000;

	public void setCapacity(int capacity) {

			this.coffeeContainerCapacity = capacity;
	}

	public int getCurrentCapacity() {
		return coffeeContainerCapacity;
	}


	@Override
	public void updateContainer(int materialUsed) {
		setCapacity( materialUsed);
	}

}
