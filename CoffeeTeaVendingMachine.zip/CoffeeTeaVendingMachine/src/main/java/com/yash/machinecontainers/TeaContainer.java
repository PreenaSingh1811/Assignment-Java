package com.yash.machinecontainers;

public class TeaContainer implements Container {

	private int teaContainerCapacity = 2000;

	public void setCapacity(int capacity) {
			this.teaContainerCapacity = capacity;
	}

	public int getCurrentCapacity() {
		return teaContainerCapacity;
	}

	@Override
	public void updateContainer(int newCapacity) {
		setCapacity(newCapacity);
	}

}
