package com.yash.machinecontainers;

public class MilkContainer implements Container {

	private int milkCapacity;

	public MilkContainer() {
		this.milkCapacity = 10000;
	}

	public void setCapacity(int capacity) {
		this.milkCapacity = capacity;
	}

	@Override
	public int getCurrentCapacity() {
		return milkCapacity;
	}

	@Override
	public void updateContainer(int newCapacity) {
		setCapacity(newCapacity);

	}

}
