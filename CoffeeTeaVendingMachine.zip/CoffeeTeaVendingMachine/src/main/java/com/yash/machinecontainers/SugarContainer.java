package com.yash.machinecontainers;

public class SugarContainer implements Container {

	private int sugarCapacity = 8000;

	public void setSugarCapacity(int sugarCapacity) {
		this.sugarCapacity = sugarCapacity;
	}

	@Override
	public int getCurrentCapacity() {
		return sugarCapacity;
	}

	@Override
	public void updateContainer(int newCapacity) {
		setSugarCapacity(newCapacity);

	}

}
