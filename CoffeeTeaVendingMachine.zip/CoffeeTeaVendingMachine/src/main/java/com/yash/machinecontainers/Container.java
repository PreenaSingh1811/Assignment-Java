package com.yash.machinecontainers;

public interface Container {

public int getCurrentCapacity();

public void updateContainer(int materialUsed);
	
	
}
