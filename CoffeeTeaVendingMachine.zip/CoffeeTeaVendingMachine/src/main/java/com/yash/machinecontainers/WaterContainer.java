package com.yash.machinecontainers;

public class WaterContainer implements Container {

	private int waterContainer = 15000;

	public void setWaterContainer(int waterCapacity) {
		this.waterContainer = waterCapacity;
	}

	@Override
	public int getCurrentCapacity() {

		return waterContainer;
	}

	@Override
	public void updateContainer(int newCapacity) {
		setWaterContainer(newCapacity);

	}

}
