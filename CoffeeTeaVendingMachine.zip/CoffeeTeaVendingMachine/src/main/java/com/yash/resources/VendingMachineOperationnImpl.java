package com.yash.resources;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;
import java.util.logging.FileHandler;

import com.yash.services.ScannerInput;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import org.apache.log4j.Logger;
import com.yash.drinks.Drinks;
import com.yash.machinecontainers.CoffeeContainer;
import com.yash.machinecontainers.Container;
import com.yash.machinecontainers.MilkContainer;
import com.yash.machinecontainers.SugarContainer;
import com.yash.machinecontainers.TeaContainer;
import com.yash.machinecontainers.WaterContainer;

public class VendingMachineOperationnImpl implements VendingMachineOperations {

	private static final Logger logger = Logger.getRootLogger();

	private static Integer refillingCounter = 0;
	private Integer coffeeWaste = 0;
	private Integer teaWaste = 0;
	private Integer waterWaste = 0;
	private Integer sugarWaste = 0;
	private Integer milkWaste = 0;
	private ScannerInput scanner = new ScannerInput();

	private ArrayList<String> drinks = new ArrayList<String>(
			Arrays.asList("Tea", "Coffee", "Black Tea", "Black Coffee"));
	private ArrayList<String> containers = new ArrayList<String>(
			Arrays.asList("Tea", "Coffee", "Sugar", "Milk", "Water"));
	private Map<String, Integer> drinksPrice = new HashMap<String, Integer>() {
		{
			put("Tea", 10);
			put("Coffee", 15);
			put("Black Tea", 5);
			put("Black Coffee", 10);
		}
	};
	private Map<String, Integer> totalNumberCup = new HashMap<String, Integer>() {
		{
			put("Tea", 0);
			put("Coffee", 0);
			put("Black Tea", 0);
			put("Black Coffee", 0);
		}
	};

	private Map<String, Drinks> drinksQuantity = new HashMap<String, Drinks>() {
		{
			put("Tea", new Drinks(5, 0, 15, 40, 60, 1, 0, 2, 4, 5));
			put("Coffee", new Drinks(0, 5, 15, 80, 20, 0, 1, 2, 3, 8));
			put("Black Tea", new Drinks(3, 0, 15, 0, 100, 0, 0, 2, 0, 12));
			put("Black Coffee", new Drinks(0, 3, 15, 0, 100, 0, 0, 2, 0, 12));
		}
	};

	private Map<String, Container> containerMap = new HashMap<>();
	private Map<String, Integer> containerMaxCapacity = new TreeMap<String, Integer>() {
		{
			
			put("Tea", 2000);
			put("Coffee", 2000);
			put("Sugar", 8000);
			put("Water", 15000);
			put("Milk", 10000);
		}
	};

	public VendingMachineOperationnImpl() {
		init();
	}

	private void init() {
		containerMap.put("Milk", new MilkContainer());
		containerMap.put("Tea", new TeaContainer());
		containerMap.put("Sugar", new SugarContainer());
		containerMap.put("Water", new WaterContainer());
		containerMap.put("Coffee", new CoffeeContainer());
	}

	@Override
	public void makeDrink(Integer numberOfCups, String drinkName) {
		Boolean flag = true;
		Map<String, Integer> leftQuantity = new HashMap<String, Integer>();
		leftQuantity.put("Milk", containerMap.get("Milk").getCurrentCapacity()
				- ((drinksQuantity.get(drinkName).getMilkQuantity() + drinksQuantity.get(drinkName).getMilkWaste())
						* numberOfCups));
		leftQuantity.put("Water", containerMap.get("Water").getCurrentCapacity()
				- ((drinksQuantity.get(drinkName).getWaterQuantity() + drinksQuantity.get(drinkName).getWaterWaste())
						* numberOfCups));
		leftQuantity.put("Sugar", containerMap.get("Sugar").getCurrentCapacity()
				- ((drinksQuantity.get(drinkName).getSugarQuantity() + drinksQuantity.get(drinkName).getSugarWaste())
						* numberOfCups));
		leftQuantity.put("Tea", containerMap.get("Tea").getCurrentCapacity()
				- ((drinksQuantity.get(drinkName).getTeaQuantity() + drinksQuantity.get(drinkName).getTeaWaste())
						* numberOfCups));
		leftQuantity.put("Coffee", containerMap.get("Coffee").getCurrentCapacity()
				- ((drinksQuantity.get(drinkName).getCoffeeQuantity() + +drinksQuantity.get(drinkName).getCoffeeWaste())
						* numberOfCups));
		for (String key : leftQuantity.keySet()) {
			if (leftQuantity.get(key) < 0) {
				flag = false;
				logger.error(" Enough Quantity of  material is not present in " + key + "!!");
				break;
			}
		}
		if (flag) {
			totalNumberCup.put(drinkName, totalNumberCup.get(drinkName) + numberOfCups);
			for (String key : containers) {
				containerMap.get(key).updateContainer(leftQuantity.get(key));
			}
			milkWaste = milkWaste + (drinksQuantity.get(drinkName).getMilkWaste() * numberOfCups);
			waterWaste = waterWaste + (drinksQuantity.get(drinkName).getWaterWaste() * numberOfCups);
			teaWaste = teaWaste + (drinksQuantity.get(drinkName).getTeaWaste() * numberOfCups);
			coffeeWaste = coffeeWaste + (drinksQuantity.get(drinkName).getCoffeeWaste() * numberOfCups);
			sugarWaste = sugarWaste + (drinksQuantity.get(drinkName).getSugarWaste() * numberOfCups);

		}

		logger.info(" Number of cups of "+drinkName+":"+ numberOfCups + " With Total price " + drinksPrice.get(drinkName) * numberOfCups);
	}

	public void refillContainer(Boolean isRefillCalled) {

		Integer refillContainerSelectionId;
		Boolean continueOrNot;
		Integer amountOfDrink;
		do {
			logger.info(" Which of the below Container you want to Refill ");
			for (int i = 0; i < containers.size(); i++) {
				logger.info(" " + (i + 1) + ". " + containers.get(i) + " Container With remaning material is "
						+ containerMap.get(containers.get(i)).getCurrentCapacity());
			}
			refillContainerSelectionId = scanner.nextInt();

			if (refillContainerSelectionId <= 5 && refillContainerSelectionId >= 1) {

				logger.info(" Enter amount of material you want to Refill ");
				amountOfDrink = scanner.nextInt();
				if ((containerMap.get(containers.get(refillContainerSelectionId - 1)).getCurrentCapacity()
						+ amountOfDrink) <= containerMaxCapacity.get(containers.get(refillContainerSelectionId - 1))) {
					containerMap.get(containers.get(refillContainerSelectionId - 1)).updateContainer(
							containerMap.get(containers.get(refillContainerSelectionId - 1)).getCurrentCapacity()
									+ amountOfDrink);

					logger.info(" Refilled Successfully with amount " + amountOfDrink);
					refillingCounter++;
				} else
					logger.info(" You have enter extra amount of material than container capacity");

			} else {
				logger.info(" Please enter valid choice !!");
			}
			logger.info("  do you want to continue refilling press 1 or 0");
			continueOrNot = scanner.nextInt() == 1 ? true : false;
			isRefillCalled = false;
		} while (continueOrNot);

	}

	public void totalSaleCalculator() {
		String drinkNm = "";
		logger.info("1. Total Tea-Coffee Sale Report Drink Wise   \n");
		System.out.println(
				"------------------------------------------------------------------------------------------------------");
		logger.info("|Drink Name	" + "|\t " + "Number of Cups   " + "   |\t\t" + " Total Price");
		for (String drinkName : drinks) {
			if (drinkName.equals("Tea") || drinkName.equals("Coffee")) {
				drinkNm = drinkName + "      ";
			} else {
				drinkNm = drinkName;
			}
			logger.info("|" + drinkNm + "	|   \t\t" + totalNumberCup.get(drinkName) + "   " + "         |\t\t\t"
					+ totalNumberCup.get(drinkName) * drinksPrice.get(drinkName) + "   ");
		}
		System.out.println(
				"-------------------------------------------------------------------------------------------------------");
		logger.info(" \n\n2. Total Tea-Coffee Sale                     \n");
		System.out.println("-----------------------------------------------------------------------------------");
		logger.info("|Total Number of Cups " + "|\t\t" + "Sum of Total Price|");
		logger.info("|" + totalNumberCup.values().stream().mapToInt(Integer::valueOf).sum() + "\t\t" + "       |\t\t"
				+ (Stream.of(totalNumberCup, drinksPrice).flatMap(map -> map.entrySet().stream())
						.collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue,
								(v1, v2) -> v1.intValue() * v2.intValue()))).values().stream()
										.mapToInt(Integer::valueOf).sum()
				+ "\t\t  |");
		System.out.println("-----------------------------------------------------------------------------------");
		System.out.println();
		logger.info("\n3. Container Status Report                   \n");
		containerMap.keySet().forEach(key -> logger.info(key + " : " + containerMap.get(key).getCurrentCapacity()));
		System.out.println();
		logger.info(" \n4. Refilling done                \n\t\t\t        " + refillingCounter + " times \n");

		logger.info("5. Total Waste Of material                   \n");
		logger.info(" Tea" + "\t\t" + " Coffee" + "\t\t" + "  Sugar" + "\t\t" + " Water" + "\t\t" + " Waste Of Milk");

		logger.info(teaWaste + "\t\t" + coffeeWaste + "\t\t" + sugarWaste + "\t\t" + waterWaste + "\t\t"
				+ milkWaste);
		System.out.println(
				"-------------------------------------------------------------------------------------------------------");
	}

	public void containerStatus() {

		logger.info(" Max Capacity of container :");
		
		logger.info("Coffee Container : 2000");
		logger.info("Milk Container : 10000");
		logger.info("Sugar Container : 8000");
		logger.info("Tea Container : 2000");
		logger.info("Water	 Container : 15000");
		

		logger.info("\n Remaning quantity of material in container :");
		containerMap.keySet().forEach(key -> logger.info(key + " : " + containerMap.get(key).getCurrentCapacity()));

	}

	public void resetContainer() {
		init();
		logger.info("Reset successFull");
	}

}
