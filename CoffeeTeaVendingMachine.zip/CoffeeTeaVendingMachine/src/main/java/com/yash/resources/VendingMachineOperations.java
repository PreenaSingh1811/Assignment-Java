package com.yash.resources;

public interface VendingMachineOperations {


	void makeDrink(Integer numberOfCups, String drinkName);
		

}
