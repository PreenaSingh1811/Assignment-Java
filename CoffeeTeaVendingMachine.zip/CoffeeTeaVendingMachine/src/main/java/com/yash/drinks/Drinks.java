package com.yash.drinks;

public class Drinks {

	private int teaQuantity;
	private int coffeeQuantity;
	private int sugarQuantity;
	private int milkQuantity;
	private int waterQuantity;
	private int teaWaste;
	private int coffeeWaste;
	private int sugarWaste;
	private int milkWaste;
	private int waterWaste;

	public Drinks(int teaQuantity, int coffeeQuantity, int sugarQuantity, int milkQuantity, int waterQuantity,
			int teaWaste, int coffeeWaste, int sugarWaste, int milkWaste, int waterWaste) {
		super();
		this.teaQuantity = teaQuantity;
		this.coffeeQuantity = coffeeQuantity;
		this.sugarQuantity = sugarQuantity;
		this.milkQuantity = milkQuantity;
		this.waterQuantity = waterQuantity;
		this.teaWaste = teaWaste;
		this.coffeeWaste = coffeeWaste;
		this.sugarWaste = sugarWaste;
		this.milkWaste = milkWaste;
		this.waterWaste = waterWaste;
	}

	public int getTeaQuantity() {
		return teaQuantity;
	}

	public int getCoffeeQuantity() {
		return coffeeQuantity;
	}

	public int getSugarQuantity() {
		return sugarQuantity;
	}

	public int getMilkQuantity() {
		return milkQuantity;
	}

	public int getWaterQuantity() {
		return waterQuantity;
	}

	public int getTeaWaste() {
		return teaWaste;
	}

	public int getCoffeeWaste() {
		return coffeeWaste;
	}

	public int getSugarWaste() {
		return sugarWaste;
	}

	public int getMilkWaste() {
		return milkWaste;
	}

	public int getWaterWaste() {
		return waterWaste;
	}



}
