
package com.yash.main;

import org.apache.log4j.BasicConfigurator;

import com.yash.services.MakeDrinkServices;


public class CoffeeVending {

	public static void main(String args[]) {
		

		System.out.println("-------------Welcome to coffee vending machine--------------");
		BasicConfigurator.configure();
		MakeDrinkServices makeDrinkServices = new MakeDrinkServices();
		makeDrinkServices.menuList();
	}

}
