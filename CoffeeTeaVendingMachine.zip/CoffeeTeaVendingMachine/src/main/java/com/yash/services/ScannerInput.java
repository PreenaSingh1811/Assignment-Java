package com.yash.services;

import java.util.Scanner;

public class ScannerInput {



	  private final Scanner scanner = new Scanner(System.in);
      
      public int nextInt() {

          return scanner.nextInt();
      }

}


