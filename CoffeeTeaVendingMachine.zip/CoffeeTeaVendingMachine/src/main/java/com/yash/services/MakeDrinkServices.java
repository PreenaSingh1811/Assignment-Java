package com.yash.services;

import org.apache.log4j.Logger;

import com.yash.resources.VendingMachineOperationnImpl;

public class MakeDrinkServices {
	private ScannerInput scanner =new ScannerInput();
	VendingMachineOperationnImpl vendingMachineOperationImpl = new VendingMachineOperationnImpl();
	private static final Logger logger = Logger.getRootLogger();
	
	public void menuList() {
		Integer menuItem, numberOfCups = null;

		do {
			System.out.println("Choose menu item of your choice: ");
			System.out.println("1. MAKE COFFEE ");
			System.out.println("2. MAKE TEA ");
			System.out.println("3. MAKE BLACK COFFEE ");
			System.out.println("4. MAKE BLACK TEA ");
			System.out.println("5. REFILL CONTAINER ");
			System.out.println("6. CHECK TOTAL SALE");
			System.out.println("7. CONTAINER STATUS ");
			System.out.println("8. RESET CONTAINER ");
			System.out.println("0. EXIT TCVM ");

			menuItem = scanner.nextInt();

			switch (menuItem) {

			case 1:

				System.out.println(" Please enter number of  Cup Of Coffee ....Each cup for RS 15 /-");
				numberOfCups = scanner.nextInt();
				vendingMachineOperationImpl.makeDrink(numberOfCups, "Coffee");
				break;

			case 2:

				System.out.println(" How many Cup Of Tea do you want ? Each cup for RS 10 /-");
				numberOfCups = scanner.nextInt();
				vendingMachineOperationImpl.makeDrink( numberOfCups, "Tea");
				break;

			case 3:

				System.out.println("How many Cup Of Black Coffee do you want ? Each cup for RS 10 /-");
				numberOfCups = scanner.nextInt();
				vendingMachineOperationImpl.makeDrink( numberOfCups, "Black Coffee");
				break;

			case 4:

				System.out.println("How many Cup Of Black Tea do you want ? Each cup for RS 5 /-");
				numberOfCups = scanner.nextInt();
				vendingMachineOperationImpl.makeDrink( numberOfCups, "Black Tea");
				break;

			case 5:

				vendingMachineOperationImpl.refillContainer(true);
				break;

			case 6:

				vendingMachineOperationImpl.totalSaleCalculator();
				break;

			case 7:

				vendingMachineOperationImpl.containerStatus();
				break;

			case 8:

				vendingMachineOperationImpl.resetContainer();
				break;

			case 0:
				logger.info(" Thanks For Using Vending Machine!!");
				logger.info(" -----Visit Again-----");
				break;

			default:
				logger.info(" Please enter valid choice !!");

			}

		} while (menuItem != 0);
	}

}
