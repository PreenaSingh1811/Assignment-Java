package com.yash.springboot.service;

import org.springframework.stereotype.Service;

@Service
public class WelcomeService {

	public String retriveMessage() {
		return "Good Morning Shankar!!";
	}
}
