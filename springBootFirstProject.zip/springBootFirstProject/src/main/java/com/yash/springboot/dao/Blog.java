package com.yash.springboot.dao;

import javax.persistence.*;

@Entity
@Table(name = "blog")
public class Blog {
	@Id
	private int id;
	@Column
	private String title;
	@Column
	private String content;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}
	
}
