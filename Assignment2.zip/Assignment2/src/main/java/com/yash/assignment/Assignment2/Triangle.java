package com.yash.assignment.Assignment2;

public class Triangle  implements Polygon{

	@Override
	public String getType() {
		
		return "Triangle";
	}

}
