package com.yash.assignment.Assignment2;

import java.util.Arrays;
import java.util.OptionalInt;

public class Check {
public static void main(String[] args) {
	
	int[] arr=new int[] {2,3,4,5,6,7,9,10,1};
	OptionalInt ans=Arrays.stream(arr).reduce(Integer::sum);
	System.out.println(ans);
	
	
	long an=Arrays.stream(arr).filter(i->i%2!=0).count();
	System.out.println(an);
}
}
