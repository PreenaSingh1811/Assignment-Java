package com.yash.assignment.Assignment2;

public class Pentagon implements Polygon {

	@Override
	public String getType() {
		return "Pentagon";
	}

}
