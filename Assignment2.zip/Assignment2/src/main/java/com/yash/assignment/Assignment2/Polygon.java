package com.yash.assignment.Assignment2;

public interface Polygon {
String getType();
}
