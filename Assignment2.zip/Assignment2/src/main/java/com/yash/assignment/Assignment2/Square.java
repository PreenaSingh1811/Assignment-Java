package com.yash.assignment.Assignment2;

public class Square implements Polygon{
	Square(){
		
	}

	@Override
	public String getType() {
		// TODO Auto-generated method stub
		return "Square";
	}

}
