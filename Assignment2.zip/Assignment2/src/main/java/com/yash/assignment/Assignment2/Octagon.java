package com.yash.assignment.Assignment2;

public class Octagon implements Polygon {

	@Override
	public String getType() {
		// TODO Auto-generated method stub
		return "Octagon";
	}

}
