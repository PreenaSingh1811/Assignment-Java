package com.yash.assignment.Assignment2;

public class Heptagon  implements Polygon{


	@Override
	public String getType() {
		// TODO Auto-generated method stub
		return "Heptagon";
	}
	
}
