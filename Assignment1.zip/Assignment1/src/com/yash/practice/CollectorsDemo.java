package com.yash.practice;

import java.util.Arrays;
import java.util.IntSummaryStatistics;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Function;
import java.util.stream.Collector;
import java.util.stream.Collectors;

public class CollectorsDemo {

	public static void main(String[] args) {
		Integer i = 0;
		List<Integer> numbers = Arrays.asList(10, 20, 30, 11, 20, 33, 4, 44, 55, 20);
		System.out.println("result in Set----------------------------------------------");
		// collect the result of a Stream into Set
		Set<Integer> numSet = numbers.stream().collect(Collectors.toSet());
		numSet.forEach(System.out::println);

		// collect the result of a Stream into list
		System.out.println("Stream in List----------------------------------------------");
		List<Integer> numList = numbers.stream().collect(Collectors.toList());
		numList.forEach(System.out::println);
		
		
		AtomicInteger index = new AtomicInteger();
		System.out.println("Result in map----------------------------------------------");
		Map<Integer, Integer> numMap = numSet.stream().collect(Collectors.toMap(in -> index.getAndIncrement(), n -> n));
		System.out.println(numMap);
		numMap.forEach((k, v) -> System.out.println("index : " + k + " value : " + v));
		
		System.out.println("summary Statistics----------------------------------------------");
		// find summary statistics from a Stream of numbers
		IntSummaryStatistics numStats = numbers.stream().collect(Collectors.summarizingInt(n -> n));
		System.out.println(numStats);
		
		System.out.println("Stream in even n odd---------------------------------------------");
		Map<Boolean, List<Integer>> evenOddNum = numbers.stream().collect(Collectors.partitioningBy(n -> n % 2 == 0));
		System.out.println(evenOddNum);
		
		System.out.println("Comma seperated numbers----------------------------------------------");
		String numString = numbers.stream().map(n -> n.toString()).collect(Collectors.joining(","));
	}
}
