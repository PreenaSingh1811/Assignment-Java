package com.yash.practice;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import com.yash.practice.Employee;

public class EmployeeTest {

	public static void main(String[] args) {
        Employee employee1 = new Employee(
                "Yash",
                20,
                new Address("1234"),
                Arrays.asList(new MobileNumber("1233"), new MobileNumber("1234")));
     
            Employee employee2 = new Employee(
                "Ram",
                20,
                new Address("1235"),
                Arrays.asList(new MobileNumber("1111"), new MobileNumber("3333"), new MobileNumber("1233")));
     
            Employee employee3 = new Employee(
                "Sita",
                20,
                new Address("1236"),
                Arrays.asList(new MobileNumber("3333"), new MobileNumber("4444")));
            
            List<Employee> employees = Arrays.asList(employee1, employee2, employee3);
            
        	System.out.println("name equals Yash--------------------------------------------");
            Stream<Employee> emp =employees.stream().filter(e->e.getName().equals("Yash"));
            Optional<Employee> answer = emp.findFirst(); 
            System.out.println(answer.isPresent()?answer.get():"not founds");
//            if (!(answer.isPresent())) { 
//                System.out.println("Not found"); 
//            }else {
//            	  System.out.println(answer);
//            }
           // Stream<Employee> empAdd =employees.stream().filter(e->e.getAddress().hashCode().equals("1235"));
                        
            System.out.println("Address equals 1235--------------------------------------------");
            Employee empAddress = employees.stream().filter(emp1 -> emp1.getAddress().getZipcode().equals("1235"))
			.findFirst().get();
            System.out.println(empAddress);
            
            System.out.println("Mobile number equals 3333--------------------------------------------");
            // Get all employee having mobile numbers 3333.
            List<Employee> empMobileNum = employees.stream().filter(x->x.getMobileNumbers().stream().anyMatch(a->a.getNumber().equals("3333"))).collect(Collectors.toList());
            empMobileNum.forEach(System.out::println);
            
            System.out.println("Get name of employees--------------------------------------------");
        	List<String> empNames= employees.stream().map(x->x.getName()).collect(Collectors.toList());
        	System.out.println(empNames);
        	
            System.out.println("name of employees to uppercase--------------------------------------------");
        	List<String> upperCase= empNames.stream().map(String::toUpperCase).collect(Collectors.toList());
        	System.out.println(upperCase);
        	
        	System.out.println("Sort name of employees ------------------------------------------");
        	List<String> sorted=  empNames.stream().sorted().collect(Collectors.toList());
        	System.out.println(sorted);
                 
            // Collect all the names of employees in a string separated by ||
        	System.out.println("Name of employees seperated by // ------------------------------------------");
        	String backslashSeperatedName=  empNames.stream().sorted().collect(Collectors.joining("// "));
        	System.out.println(backslashSeperatedName);
            
        	System.out.println("Sort  employees on name  ------------------------------------------");
        	employees.sort((e1, e2)->e1.getName().compareTo(e2.getName()));
        	employees.forEach(System.out::println);
          
                             
	}
}
