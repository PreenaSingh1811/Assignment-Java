package com.yash.example;

interface Message {
	 ConstructorRef getMessage(String msg);
	
}
