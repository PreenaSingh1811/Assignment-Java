package com.yash.example;


interface Shape {
	

	double calculate(double area);
	//ConstructorRef calculate2(double area);
	

}
