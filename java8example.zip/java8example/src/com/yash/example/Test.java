package com.yash.example;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class Test {
	
	public static void main(String args[]) {
		double side=5.0;
		Shape area= (double x)->x*x;
		double ans=area.calculate(side);
		
		System.out.println("The area is "+ans);
		System.out.println("Constructor Exp------------------");
		Message s=ConstructorRef::new;
		
		s.getMessage("Hello to Constructor Reference");
		
		Employee e1= new Employee();
		Employee e2= new Employee();
		Employee e3= new Employee();
		e1.id=5;
		e2.id=2;
		e3.id=7;
		e1.name="Preena";
		e2.name="Shankar";
		e3.name="Sai";
		ArrayList<Employee> list1=new ArrayList<Employee>();
		list1.add(e1);
		list1.add(e2);
		list1.add(e3);
		Comparator<Employee> comp=(emp1,emp2)->{return emp1.getName().compareTo(emp2.getName());};
			
		Collections.sort(list1, Comparator.comparing(Employee::getId));
		list1.stream().forEach(System.out::println) ;
		
		A a=new C();
		a.m1();
	}
		Shape s1=MethodRef::area;
		double ans1=s1.calculate(5.0);
		
		
		
	}


