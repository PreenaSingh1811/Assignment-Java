package com.yash.example;

public class MethodRef {
	public static double area(double a) {
		return a*a;
	}

}
