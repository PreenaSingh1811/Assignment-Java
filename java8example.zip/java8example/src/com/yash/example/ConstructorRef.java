package com.yash.example;

public class ConstructorRef {
	public ConstructorRef(String msg) {
		System.out.println(msg);
		// TODO Auto-generated constructor stub
	}
}
