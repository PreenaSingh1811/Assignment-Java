package com.yash.example;

public class A {
protected synchronized void m1() {
	System.out.println("A");
}
}
