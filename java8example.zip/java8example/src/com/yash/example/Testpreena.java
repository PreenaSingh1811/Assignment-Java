package com.yash.example;

public class Testpreena {

	public static void main(String args[]) {
		Testpreena t1 = new Testpreena();
		System.out.println(t1.iterativeGCD(2, 4));
		int count = 0;
		for (int i = 1; i < 2; i++) {
			if (t1.iterativeGCD(i, 2)) {
				count++;
			}
		}
		System.out.println(count);
		int array[]={1,1,4};
		System.out.println(atMostSum(array, 3, 3));
	}

	public static int atMostSum(int arr[], int n, 
                                        int k) 
    { 
        int sum = 0; 
        int cnt = 0, maxcnt = 0; 
      
        for (int i = 0; i < n; i++) { 
              
            // If adding current element doesn't 
            // cross limit add it to current window 
            if ((sum + arr[i]) <= k) { 
                sum += arr[i];  
                cnt++; 
            }  
      
            // Else, remove first element of current 
            // window. 
            else if(sum!=0) 
           { 
            sum = sum - arr[i - cnt] + arr[i]; 
           } 
      
            // keep track of max length. 
            maxcnt = Math.max(cnt, maxcnt);  
        } 
        return maxcnt; 
    }

	boolean iterativeGCD(int a, int b) {
		int tmp;
		while (b != 0) {
			if (a < b) {
				tmp = a;
				a = b;
				b = tmp;
			}
			tmp = b;
			b = a % b;
			a = tmp;
		}
		if (a == 1) {
			return true;
		} else {
			return false;
		}

	}
}
