package com.yash.example;

public class C extends B {
	void m1() {
		System.out.println("C");
	}
}
