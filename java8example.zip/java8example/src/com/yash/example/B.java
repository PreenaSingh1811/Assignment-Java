package com.yash.example;

public class B  extends A{
	public synchronized void m1() {
		System.out.println("B");
	}
}
