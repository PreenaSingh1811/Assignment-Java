package com.yash.streamexample;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import com.yash.example.Employee;

public class Test {
	
	public static void main(String args[]) {
		
		Employee e1= new Employee();
		Employee e2= new Employee();
		Employee e3= new Employee();
		e1.setId(5);
		e2.setId(2);
		e3.setId(7);
		e1.setName("Preena");
		e2.setName("Purvi");
		e3.setName("Sai");
		ArrayList<Employee> empList=new ArrayList<Employee>();
		empList.add(e3);
		empList.add(e2);
		empList.add(e1);
		System.out.println(empList);
		Predicate<Employee> p1 = s -> s.getName().startsWith("S"); 
		Predicate<Employee> p2= s -> s.getName().startsWith("N");
		boolean answer = empList.stream().anyMatch(p1); 
		boolean answer1 = empList.stream().noneMatch(p2);
		System.out.println("Any match-----------------------------------------");
		System.out.println(answer);
		
		System.out.println("Non match-------------------------------------------");
		System.out.println(answer1);
		System.out.println("Stream of-----------------------------------------");
		Stream<Integer> num=Stream.of(1,2,3,4,5);
		num.forEach(System.out::println);
		
		System.out.println("Concat-------------------------------------------");
		Stream<String> strm1=Stream.of("Preena "," Sai ","SHankar ");
		  Stream<String> strm2=Stream.of("Priya "," Purvi ","SHankar ");
		Stream.concat(strm1, strm2).distinct().forEach(System.out::println);
		Optional<Employee> answer3 = empList.stream().findFirst(); 
		System.out.println("FindFirst--------------------------------------------");
		if (answer3.isPresent()) { 
            System.out.println(answer3.get()); 
        } 
		else {
			System.out.println("no value"); 
		}
		  Optional<Employee> answer4 = empList.stream().findAny(); 
		  System.out.println("FindAny--------------------------------------------");
		  System.out.println(answer4.get()); 
		  System.out.println("count--------------------------------------------");
		  Stream<String> strm3=Stream.of("Priya "," Purvi ","SHankar ");
		  Stream<String> strm4=Stream.of("Priya "," Purvi ","SHankar ");
		  long a=Stream.concat(strm3,strm4).count();
		  System.out.println( a);
		  System.out.println("Peek--------------------------------------------");
		  Stream<String> nameStream = Stream.of("Preena", "Ritu", "Neha");
		 long c= nameStream.peek(System.out::println).count();
		 System.out.println(c);
		 
		
	}

}
