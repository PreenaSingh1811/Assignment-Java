package com.yash.collectorsexampls;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.DoubleSummaryStatistics;
import java.util.IntSummaryStatistics;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Test {

	public static void main(String args[]) {
		
		Item item1= new Item("orange",2,20.0);
		Item item2= new Item("apple",2,200.0);
		Item item3= new Item("kivi",10,400.0);
		//Item item4= new Item("orange",2,20.0);
		Item item5= new Item("plum",7,1000.0);
		Item item6= new Item("banana",9,80.0);
		List<Item> listItem= new ArrayList<Item>();
		listItem.add(item6);
		listItem.add(item5);
		//listItem.add(item4);
		listItem.add(item3);
		listItem.add(item2);
		listItem.add(item1);
		Map<String, Double> groubyNAME = listItem.stream()
				.collect(Collectors.groupingBy(Item::getName,Collectors.summingDouble(Item::getPrice)));
		System.out.println("items grouped by name" +groubyNAME );
		Stream<Integer> num=Stream.of(1, 2, 3, 4, 5, 6, 7, 8, 9, 10);
		 Map<Boolean, List<Integer> > 
         map = num.collect( 
             Collectors.partitioningBy(n -> n > 3)); 
		 System.out.println(map);
		 
		 
		 Stream <Item> item=Stream.of(item1,item2,item3);
		 Map<Boolean, List<Item>> price=listItem.stream().
				 collect(Collectors.partitioningBy(n->n.price>100));		 
		 System.out.println(price);
		 
		 
		 Map<String, Double> result1 = listItem.stream().collect(
	                Collectors.toMap(Item::getName, Item::getPrice));
		 System.out.println(result1);
		 DoubleSummaryStatistics s=listItem.stream().collect(Collectors.summarizingDouble(Item::getPrice));
		 System.out.println(s);

		 System.out.println("Reduce--------------------------------------------");
		 List<Integer> numbers = Arrays.asList(1, 2, 3, 4, 5, 6);
		 int result = numbers
		   .stream()
		   .reduce(0, (subtotal, element) -> subtotal + element);
		 System.out.println(result);
		 System.out.println("Limit--------------------------------------------");
		 Stream<Integer> evenNumInfiniteStream = Stream.iterate(0, n -> n + 2);
	     List<Integer> newList = evenNumInfiniteStream.limit(10).collect(Collectors.toList());
	     System.out.println(newList);
	     System.out.println("Skip--------------------------------------------");
	     Stream<Integer> oddNumInfiniteStream = Stream.iterate(1, n -> n + 2).limit(20);
	     List<Integer> newOddList = oddNumInfiniteStream.skip(10).collect(Collectors.toList());
	     System.out.println(newOddList);
	     System.out.println("Averaging int--------------------------------------------");
	     Stream<Integer> oddNumInfiniteStream2 = Stream.iterate(1, n -> n + 2).limit(20);
	     double s1= oddNumInfiniteStream2.collect(Collectors.averagingInt(n->n));
	     System.out.println(s1);

		
		
		
	}
	
	
}
