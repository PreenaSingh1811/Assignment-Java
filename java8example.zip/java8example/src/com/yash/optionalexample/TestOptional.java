package com.yash.optionalexample;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.function.Predicate;

public class TestOptional {

	public static void main(String args[]) {

		String[] str = new String[5]; 


		str[2] = "Hello World"; 

		Optional<String> empty = Optional.empty(); 
		System.out.println(empty); 

		 
		Optional<String> value = Optional.of(str[2]); 
		System.out.println(value); 
		System.out.println("ofNullable on Non-Empty Optional: " + Optional.ofNullable(str[2]));
		System.out.println("ofNullable on Empty Optional: " + Optional.ofNullable(str[4]));
		//System.out.println("ofNullable on Non-Empty Optional: " + Optional.of(str[4]));
	
		System.out.println("Map-------------------------------------------------------");
		Optional<String> gender=Optional.of("Female");
		Optional<String> emptyString=Optional.empty();
		System.out.println("Non empty map"+gender.map(String::toUpperCase));
		System.out.println("Non empty map"+emptyString.map(String::toUpperCase));
		
		System.out.println("FlatMap-------------------------------------------------------");
		Optional<Optional<String>> nonEmptyOtionalGender = Optional.of(Optional.of("male"));
        System.out.println("Optional value   :: " + nonEmptyOtionalGender);
        System.out.println("Optional.map     :: " + nonEmptyOtionalGender.map(n -> n.map(String::toUpperCase)));
        System.out.println("Optional.flatMap :: " + nonEmptyOtionalGender.flatMap(n -> n.map(String::toUpperCase)));
        System.out.println("Filter-------------------------------------------------------");
        Integer a=new Integer(10);
        Optional<List<Integer>> num=Optional.of(Arrays.asList(1,2,3,4,5));
       // System.out.println(num.filter(n->(n%2==0)));
        
	} 
}
