package com.yash.junitexample;

public class Caculate {
	
	public int sum(int a,int b) {
		return a+b;
	}

}
