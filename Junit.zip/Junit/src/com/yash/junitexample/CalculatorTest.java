package com.yash.junitexample;



public class CalculatorTest {
	
	Caculate c=new Caculate();
	int sum=c.sum(6, 8);
	
	
	
	
	@Test
	public void testSumMethod() {
		assertEquals(sum,14);
	}

}
