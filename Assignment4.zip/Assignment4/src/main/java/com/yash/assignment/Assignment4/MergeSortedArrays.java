package com.yash.assignment.Assignment4;

public class MergeSortedArrays {
 public int[] Merge(int[] nums1, int[] nums2)

    {
	 int lengthOfArr1=nums1.length;
	 int lengthOfArr2=nums2.length;
     int k = lengthOfArr1 + lengthOfArr2 - 1;
     
     int[] arr3=new int[k];
//System.out.println(lengthOfArr1 +"    "+lengthOfArr2);
        int i = lengthOfArr1 - 1;
        int j = lengthOfArr2- 1;
        k=k-1;
        while (i >= 0 && j >= 0)
        {
        	System.out.println("Hello");
            if (nums1[i] > nums2[j])
            {
            	//System.out.println(nums1[i]);
                arr3[k] = nums1[i];
                //System.out.println(arr3[k]);
                i--;
            }
            else
            {
                arr3[k] = nums2[j];
                j--;
            }
            k--;
           // System.out.println(nums1[k]);
        }

        while (j >= 0)
        {
            arr3[k--] = nums2[j--];
        }
        
        return arr3;
    }
 public static void main(String[] args) {
		MergeSortedArrays t=new MergeSortedArrays();
		int[] arr=new int[]{1,8,9,15,20,71};
		int[] arr2=new int[]{11,13,14,17};
		int[] arr3=t.Merge(arr,arr2);
		for(int i=0;i<arr.length;i++) {
			System.out.println(arr3[i]); }


	
	}
}


