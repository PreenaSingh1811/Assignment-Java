package com.yash.assignment.Assignment4;

public class RotateArray {

	public int[] toRotateArray(int arr[],int num) {

		int len=arr.length;
		int[] arrayAfterRotation= new int[len];
		for(int i=num+1,k=0,j=0;k<=num&&i<len;i++,k++,j++) {
			arrayAfterRotation[j]=arr[i];
			arrayAfterRotation[i-1]=arr[k];
		}
		arrayAfterRotation[len-1]=arr[num];

		/*
		 * for(int i=0;i<=num;i++) { arrayAfterRotation[j]=arr[i]; j++; }
		 */

		return arrayAfterRotation;
	}
	public static Object m1(Object m) {
		System.out.println("Obj");
		return null;
	}
	public static String m1(String a) {
		System.out.println("String");
		return "";
	}
	public static int m1(Integer a) {
		System.out.println("int");
		return 1;
	}
	
	public static void main(String[] args) {
		RotateArray r=new RotateArray();
		int[] arr=new int[]{1,2,3,4,5,6,7};

		int arr2[]=r.toRotateArray(arr, 3); 
		for(int i=0;i<arr.length;i++) {
			System.out.println(arr2[i]); 
			}
	
	m1(null);
	}
}
