package com.yash.assignment.Assignment4;

public class Maruti implements Car{

}
