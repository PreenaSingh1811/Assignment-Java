package com.yash.assignment.Assignment4;

import java.util.HashMap;
import java.util.Map;

public class ManagerEmployee {
	
	public static void main(String[] args) {
		Map<String, String> map=new HashMap<String, String>();
		map.put("Nikhil", "Rajat");
		map.put("Rajat", "Sai");
		map.put("Sai", "Pranali");
		map.put("Ashmi", "Ekta");
		map.put("Ekta", "Mayank");
		
		String name="Nikhil";
		String a="abc";
		String b="xyz";
		String d=new String ("abc");
		System.out.println(a+b);
		String c=a;
		System.out.println(a==c);
		System.out.println(a.equals(c));
		System.out.println("   "+a==d);
		
		
		System.out.println(getManagers(name, map));
	}
	
	public static String getManagers(String name,Map<String,String> map) {
		String value="";
		int i=10;
		String j=String.valueOf(i);
		Integer a=new Integer(10);
		int b=a;
		do {
		
			if(map.containsKey(name)) {
				 value=value+" "+map.get(name);
				 name=map.get(name);
			}
		}while(map.containsKey(name));
		

		return value;
	}

}
