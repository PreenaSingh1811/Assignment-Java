package com.yash.assignment.Assignment4;

import java.util.Arrays;
import java.util.stream.IntStream;

public class ThirdLargestNumber {
	public int toFindSecondHighestNumber(int[] arr) {
		IntStream arrayOfDistinctElem=Arrays.stream(arr).distinct().sorted();
		arr=arrayOfDistinctElem.toArray();
		if(arr.length<3) {
			return 0;
		}else {
			return arr[arr.length-3];
		}
		
		
	}
	public static void main(String[] args) {
		ThirdLargestNumber t=new ThirdLargestNumber();
		int[] arr=new int[]{6,2,8,8};
		System.out.println(t.toFindSecondHighestNumber(arr));
	}

}
