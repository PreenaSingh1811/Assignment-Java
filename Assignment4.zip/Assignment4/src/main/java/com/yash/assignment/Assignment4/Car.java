package com.yash.assignment.Assignment4;

public interface Car {

}
