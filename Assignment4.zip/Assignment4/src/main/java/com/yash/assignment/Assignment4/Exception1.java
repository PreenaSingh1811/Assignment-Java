package com.yash.assignment.Assignment4;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

public class Exception1 {
	public static void main(String[] args) {

		try {
			go();
		} catch (RuntimeException e) {
			System.out.println("In main");
		}
		System.out.println("After main catch");
		HashMap<Integer, String> m = new HashMap<>();
		m.put(1, "a");
		m.put(9, "b");
		m.put(6, "c");
		Set set = m.keySet();
		Set treeSet = new TreeSet<>(set);
		System.out.println(treeSet);

		Thread t = new Thread(new MyThread());
		t.start();
		System.out.println("Main t");
		t.start();

	}

	public static void go() {
		try {
			System.out.println("in go");
			throw new RuntimeException();
		} catch (Exception e) {
			System.out.println("In go catch");
		}
	}

}
