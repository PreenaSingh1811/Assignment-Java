package com.yash.assignment.Assignment4;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class Fibonacci {
	
	public static void main(String[] args) {
		int n = 9; 
	    System.out.println(fibonacci(n)); 
	    
	    
	   List<Car> ls=new ArrayList<Car>();
	   
	   
	   ls.add((Car) new BMW());
	   ls.add((Car) new BMW());
	   ls.add((Car) new BMW());
	   ls.add((Car) new BMW());
	   ls.add((Car) new BMW());
	   ls.add((Car) new BMW());
	   ls.add((Car) new Maruti());
	   ls.add((Car) new Maruti());
	   ls.add((Car) new Maruti());
	   
	   Map<Object, Long> mp=ls.stream().collect(Collectors.groupingBy(i->i.getClass(),Collectors.counting())) ;
	   mp.forEach((name, count) -> {
           System.out.println(name + ":" + count);
	   });
		
	}
public static int fibonacci(int n) { 
	 
	    { 
	    if (n <= 1) 
	       return n; 
	    return fibonacci(n-1) + fibonacci(n-2); 
	    } 
	       
	  
	
	
	
	
	
	
}
}
