package com.yash.assignment.Assignment4;

public class AddtionOfBinary {
	public static String add(String first, String second) {
	    int b1 = Integer.parseInt(first, 2);
	    int b2 = Integer.parseInt(second, 2);
	    int sum = b1 + b2;
	    return Integer.toBinaryString(sum);
	  }
	public static void main(String[] args) {
		System.out.println(add("101","1"));
	}
	
}
