package com.yash.assignment.Assignment4;

public class BMW implements Car{

}
