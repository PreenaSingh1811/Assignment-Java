package com.yash.assignment.Assignment4;

public class MyThread implements Runnable {

	@Override
	public void run() {
	System.out.println("Hello");		
	}
	

}
