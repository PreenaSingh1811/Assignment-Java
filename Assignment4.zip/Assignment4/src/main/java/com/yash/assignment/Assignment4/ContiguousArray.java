package com.yash.assignment.Assignment4;

public class ContiguousArray {

	
	public int FindGreatestSumOfSubArray(int[] array) {
		
	if(array.length==0) 
		return 0;
	int maxSum = array[0];
	int arr = array[0];
	for (int i = 1; i < array.length; i++) {

	        if (arr < 0) {  
	            arr = array[i];  
	        } else {                              
	           arr += array[i];  
	        }                                                    
	        maxSum = maxSum>arr?maxSum:arr;  
	    }  
	    return maxSum;  
	}
	
	public static void main(String[] args) {
		ContiguousArray c=new ContiguousArray();
		int[] array=new int[] {-2,1,-3,4,-1,2,1,-5,4};
		System.out.println(c.FindGreatestSumOfSubArray(array));
	}
}
