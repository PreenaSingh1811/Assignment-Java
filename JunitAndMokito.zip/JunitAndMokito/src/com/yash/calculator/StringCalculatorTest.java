package com.yash.calculator;

import static org.junit.Assert.assertEquals;
import static org.hamcrest.CoreMatchers.containsString;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;

public class StringCalculatorTest {

	@Rule
	public ExpectedException expectedException = ExpectedException.none();

	StringCalculator object = new StringCalculator();

	@Test
	public void shouldReturnZeroforBlankStringInput() {

		Integer actual = object.calculateSumofString(null);
		assertEquals(0, actual.intValue());
	}

	@Test
	public void shouldReturntheNumberforSingleInput() {

		Integer actual = object.calculateSumofString("5");
		assertEquals(5, actual.intValue());

	}

	@Test
	public void shouldReturnSumoftheNumbersforDoubleInput() {

		Integer actual = object.calculateSumofString("5,7");
		assertEquals(12, actual.intValue());

	}

	@Test
	public void shouldReturnSumoftheNumbersforMorethanTwoNumber() {
		StringCalculator object = new StringCalculator();
		Integer actual = object.calculateSumofString("5,7,8,9");
		assertEquals(29, actual.intValue());

	}

	@Test
	public void shouldReturnSumoftheNumbersforMorethanTwoNumbersepartedBySlashn() {
		Integer actual = object.calculateSumofString("5\n7,8,9\n");
		assertEquals(29, actual.intValue());

	}

	@Test
	public void shouldReturnSumoftheNumbersforCustomizedDelimeter() {
		Integer actual = object.calculateSumofString("//;\n5;7;8;9");
		assertEquals(29, actual.intValue());

	}

	@Test
	public void shouldThrowRuntimeExceptionIfNegativeNumberPassed() {

		expectedException.expect(StringCalculatorException.class);
		expectedException.expectMessage(containsString("Negative number not allowed"));
		StringCalculator object = new StringCalculator();
		object.calculateSumofString("//;\n5;7;-8;9");

	}

	@Test
	public void shouldInoreNumberGreaterThanThousand() {

		StringCalculator object = new StringCalculator();
		Integer actual = object.calculateSumofString("//;\n5;7;1001;8;9");
		assertEquals(29, actual.intValue());
	}

	@Test
	public void shouldThrowRuntimeExceptionIfNegativeNumberPassedWithDelimeterAsDash() {

		expectedException.expect(StringCalculatorException.class);
		expectedException.expectMessage(containsString("Negative number not allowed"));
		StringCalculator object = new StringCalculator();
		object.calculateSumofString("//-\n5-7--8-9");

	}

	@Test
	public void shouldThrowRuntimeExceptionIfNegativeNumberPassedANDDelimeterIsNotDash() {

		expectedException.expect(StringCalculatorException.class);
		expectedException.expectMessage(containsString("Negative number not allowed"));
		object.calculateSumofString("5,7,-8,9");

	}

}
