package com.yash.calculator;

import java.util.List;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import static java.util.stream.Collectors.joining;

import java.util.Arrays;

import org.apache.commons.lang.StringUtils;

public class StringCalculator {

	private static Logger logger = Logger.getLogger(StringCalculator.class.getName());

	public Integer calculateSumofString(String inputString) {

		if (StringUtils.isEmpty(inputString)) {
			logger.info("The output for blank string is 0");
			return 0;
		} else if (!(inputString.contains("//")) && inputString.contains("-")) {
			throw new StringCalculatorException("Negative number not allowed");
		} else if ((inputString.contains("//")) && (inputString.contains("--") || inputString.contains("-"))) {
			throw new StringCalculatorException("Negative number not allowed");
		} else {

			if (inputString.startsWith("//")) {
				String delimiter = Character.toString(inputString.charAt(2));
				inputString = inputString.substring(3);
				logger.info("The output for  string is  " + splitInputStringByGivenDelimeter(inputString, delimiter));
				return splitInputStringByGivenDelimeter(inputString, delimiter);
			}
			/*
			 * long count = inputString.chars().filter(ch -> ch == (char)delimiter).count();
			 * if (count == 0) { return Integer.parseInt(inputString); } else if(count >= 1)
			 * { int sum = 0;
			 * 
			 * String[] value = inputString.split(delimiter); for (String str:value) { sum =
			 * sum + Integer.parseInt(str.trim()); } return sum; /* } else { return 0; }
			 */

			if (inputString.contains("\n") || inputString.contains(",")) {
				return splitInputStringByGivenDelimeter(inputString, ",|\n");
			} else {
				return Integer.parseInt(inputString);
			}

		}

	}

	private Integer splitInputStringByGivenDelimeter(String inputString, String delimiter) {
		/*
		 * long count = inputString.chars().filter(ch -> ch == (char)delimiter).count();
		 * if (count == 0) { return Integer.parseInt(inputString); } else if(count >= 1)
		 * {
		 */
		int sum = 0;

		String[] value = inputString.split(delimiter);

		sum = Arrays.asList(value).stream().map(number -> Integer.parseInt(number.trim()))
				.filter(number -> number < 1000).reduce(Integer::sum).get();

//		for (String str : value) {
//			if (Integer.parseInt(str.trim()) > 1000) {
//				continue;
//			} else {
//				sum = sum + Integer.parseInt(str.trim());
//			}
//		}

		logger.info("The sum is " + sum);
		return sum;
		/*
		 * } else { return 0; }
		 */

	}

}
