package com.yash.calculator;

public class StringCalculatorException extends RuntimeException {

	public StringCalculatorException(String msg) {
		super(msg);
	}

}
