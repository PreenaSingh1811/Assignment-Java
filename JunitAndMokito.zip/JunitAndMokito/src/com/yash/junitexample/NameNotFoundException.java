package com.yash.junitexample;

public class NameNotFoundException extends Exception{
	 private int errCode;
	public NameNotFoundException(int errCode, String message) {
        super(message);
        this.errCode = errCode;
    }

}
