package com.yash.junitexample;

import java.util.ArrayList;
import java.util.List;

public class Test {
	
	public static void main(String args[]) {
		
		List<Integer> l2=new ArrayList<>();
	//	add(l2);
		
	}
	public static List add(List<Object> l1) {
		return l1;
		
	}

}
