package com.yash.junitexample;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.isA;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;

import java.io.File;
import java.io.IOException;

import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TemporaryFolder;
public class MatcherTest {

	@Rule
	public TemporaryFolder tempFolder = new TemporaryFolder();

	@Test
	public void testCreateFile() throws IOException {
		File file = tempFolder.newFile("test.txt");
		assertTrue(file.exists());
	}

	@Test
	public void testDeleteFile() throws IOException {
		File file = tempFolder.newFile("test.txt");
		file.delete();
		assertFalse(file.exists());
	}

	@Test
	public void testCreateFolder() throws IOException {
		File file = tempFolder.newFolder("testfolder");
		assertTrue(file.exists());

	}
	
	 
    int totalNumberOfApplicants = 0;
     
    @Before
    public void setData(){
        this.totalNumberOfApplicants = 9;
    }
     
    @Test
    public void testAssertThatEqual() {
        assertThat("123",is("123"));
    }
     
    @Test
    public void testAssertThatNotEqual() {
        assertThat(totalNumberOfApplicants,is(123));
    }
     
    @Test
    public void testAssertThatObject() {
        assertThat("123",isA(String.class));
    }
     
    @Test
    public void testAssertThatWMessage(){
        assertThat("They are not equal!","123",is("1234"));
    }
}
