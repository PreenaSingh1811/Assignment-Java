package com.yash.junitexample;

import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertSame;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.rules.TemporaryFolder;

public class CalculateTest {

	Calculate c = new Calculate();
	Calculate c2 = new Calculate();
	int sum = c.sum(6, 8);

	@Rule
	public TemporaryFolder temp = new TemporaryFolder();

	@Test
	public void testSumMethod() throws NameNotFoundException {
		String a = null;
		String name = "Preena";
		boolean val = true;
		boolean val2 = false;
		int[] arr1 = { 1, 2, 3 };
		int[] arr2 = { 1, 2, 3 };
		expException.expect(NameNotFoundException.class);
		expException.expectMessage("Name is not Preena ");
		Calculate c = new Calculate();
		c.name("Priya");
		assertEquals(sum, 14);
		assertNotEquals("Preena", "preena");
		assertNull(a);
		assertNotNull(name);
		assertFalse(val2);
		assertSame(c, c2);
		assertArrayEquals(arr1, arr2);
		// .assertThat("Preena", is(equals("Preena")));

	}

	@Before
	public void testBeforeFunctionality() {
		System.out.println("@Before ");
	}

	@BeforeClass
	public static void testBeforeClassFunctionality() {
		System.out.println("@Before Class");
	}

	@AfterClass
	public static void testAfterClassFunctionality() {
		System.out.println("@After Class");
	}

	@After
	public void testAfterFunctionality() {
		System.out.println("@After");
	}

	@Ignore
	public void testIgnoreFunctionality() {
		System.out.println("@Ignore");
	}

	@Rule
	public ExpectedException expException = ExpectedException.none();

}
