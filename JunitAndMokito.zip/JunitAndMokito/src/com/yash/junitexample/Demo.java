package com.yash.junitexample;

import java.util.ArrayList;

import org.junit.Test;
import org.mockito.Mockito;
 
public class Demo {
	ArrayList mockedList = Mockito.mock(ArrayList.class);

	@Test()
	public void test() {
		Mockito.when(mockedList.get(0)).thenReturn("First");
		Mockito.when(mockedList.get(1)).thenReturn(new RuntimeException());
		System.out.println(mockedList.get(0));
		System.out.println(mockedList.get(1));
	}
}
