package com.yash.junitexample;

public class Calculate {
	public int sum(int a,int b) {
		return a+b;
	}
	public int divide(int a,int b) {
		return a/b;
	}
	public void name(String name) throws NameNotFoundException {
		if(!(name.equals("Preena")) ){
			throw new NameNotFoundException(1,"Name is not Preena ");
		}
	}

}
