package com.yash.mokitoexample;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.util.HashSet;
import java.util.Set;

import org.junit.Test;

public final class Point {
	@Test
	 public void reflexive() {
	  User x = new User(1, "x","yellow");
	  assertTrue(x.equals(x));
	 }
	
	 @Test
	 public void logicalEquality() {
	  User x1 = new User(1, "x", "yellow");
	  User x2 = new User(1, "x", "yellow");
	
	  assertTrue(x1.equals(x2) && x2.equals(x1));
	
	  
	  x1.setFavoriteColor("red");
	  x2.setFavoriteColor("blue");
	  assertTrue(x1.equals(x2) && x2.equals(x1));
	
	  x2.setId(2);
	  x2.setUsername("x2");
	  assertFalse(x1.equals(x2));
	 }
	
	 @Test
	 public void entityInSet() {
	  Set<User> set = new HashSet<User>();
	  set.add(new User(1, "x","green"));
	  set.add(new User(1, "x","green"));
	  assertEquals(1, set.size());
	 }
	
	
	 @Test
	 public void differentManagersReturnSameEntity() {
	  UserManager um1 = new UserManager();
	  UserManager um2 = new UserManager();
	
	  Set<User> set = new HashSet<User>();
	  set.add(um1.getUser());
	  set.add(um2.getUser());
	
	  assertEquals(1, set.size());
	 }
}
