package com.yash.mokitoexample;

public class WrongexceptionDish extends RuntimeException{
	

}
