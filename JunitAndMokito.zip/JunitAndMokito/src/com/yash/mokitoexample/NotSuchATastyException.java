package com.yash.mokitoexample;

public class NotSuchATastyException  extends RuntimeException{

}
