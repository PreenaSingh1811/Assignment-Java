package com.yash.mokitoexample;

public class User {
	int id;
	String userName;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return userName;
	}
	public void setUsername(String name) {
		this.userName = name;
	}
	public String getColor() {
		return color;
	}
	public void setFavoriteColor(String color) {
		this.color = color;
	}
	public User(int id, String name, String color) {
		super();
		this.id = id;
		this.userName = name;
		this.color = color;
	}
	String color;
	

}
