package com.yash.mokitoexample;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.util.Arrays;
import java.util.List;

import org.junit.Test;
import org.mockito.ArgumentCaptor;
import  org.mockito.Mockito;
public class CaptorTest {

@Test
public void test() {
	MathUtils mockMathUtils =Mockito.mock(MathUtils.class);
	Mockito.when(mockMathUtils.add(1, 1)).thenReturn(2);
	Mockito.when(mockMathUtils.isInteger(Mockito.anyString())).thenReturn(true);

	ArgumentCaptor<Integer> acInteger = ArgumentCaptor.forClass(Integer.class);
	ArgumentCaptor<String> acString = ArgumentCaptor.forClass(String.class);

	assertEquals(2, mockMathUtils.add(1, 1));
	assertTrue(mockMathUtils.isInteger("1"));
	assertTrue(mockMathUtils.isInteger("999"));

	Mockito.verify(mockMathUtils).add(acInteger.capture(), acInteger.capture());
	
	
	List allValues = acInteger.getAllValues();
	assertEquals(Arrays.asList(1, 1), allValues);
	
	Mockito.verify(mockMathUtils, Mockito.times(2)).isInteger(acString.capture());
	List allStringValues = acString.getAllValues();
	assertEquals(Arrays.asList("1", "999"), allStringValues);
}


}
