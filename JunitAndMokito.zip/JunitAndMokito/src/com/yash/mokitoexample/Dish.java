package com.yash.mokitoexample;

public interface Dish {
    void eat() throws WrongexceptionDish;
}
