
package com.yash.mokitoexample;

public class Customer {
	public void eat(Dish dish) throws WrongexceptionDish {
        try {
            System.out.println("Taste the food");
            dish.eat();
            System.out.println("Ate the food");
        } catch (WrongexceptionDish e) {
            System.out.println("Wrong dish!");
            throw e;
        } catch (NotSuchATastyException e) {
            System.out.println("Not very tasty");
            throw e;
        }       
    }
}
