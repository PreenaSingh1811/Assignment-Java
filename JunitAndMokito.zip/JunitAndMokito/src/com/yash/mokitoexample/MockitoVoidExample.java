package com.yash.mokitoexample;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

public class MockitoVoidExample {
	private Customer customer;
	private Dish dish;

	@Before
	public void setupMock() {
		customer = new Customer();
		dish = Mockito.mock(Dish.class);
	}

	@Test
	public void testEatUsingStubVoid() throws WrongexceptionDish {
		System.out.println("Train dish to not throw WrongDishException using stubVoid");
		Mockito.verify(dish).eat();
		customer.eat(dish);
		System.out.println("Finished the dish, no exception thrown");
	}

}
