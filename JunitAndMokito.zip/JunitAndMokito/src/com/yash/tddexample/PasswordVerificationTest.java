package com.yash.tddexample;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class PasswordVerificationTest {
	
	@Test
	public void shouldTestCorrectConditionForPassword() {
		String password = "Arya1234";
		String checkdigit ="Aryasingh";
		String checkUpperCase ="arya1234";
		String checkLowerCase="ARYA1234";
		String checkNull=null;
		String checkLength="Arya";
		String checkBlankString= "";

		PasswordVerification object = new PasswordVerification();
		String passwordCheck = object.shouldVerifiyPasswordEligibility(password);
		String passwordCheckDigitCondition = object.shouldVerifiyPasswordEligibility(checkdigit);
		String passwordCheckUpperCaseCondition = object.shouldVerifiyPasswordEligibility(checkUpperCase);
		String passwordCheckLowerCaseCondition = object.shouldVerifiyPasswordEligibility(checkLowerCase);
		String passwordCheckNull = object.shouldVerifiyPasswordEligibility(checkNull);
		String passwordCheckLength=object.shouldVerifiyPasswordEligibility(checkLength);
		String passwordCheckBlank=object.shouldVerifiyPasswordEligibility(checkBlankString);
		
		
		  assertEquals("correct Password", passwordCheck);
		  assertEquals("Should contain 1 digit", passwordCheckDigitCondition);
		  assertEquals("Should contain 1 upper case", passwordCheckUpperCaseCondition);
		  assertEquals("Should contain 1 lower case", passwordCheckLowerCaseCondition);
		  assertEquals("The password should not be empty", passwordCheckNull);
		  assertEquals("The password should not be less than 8 character",
		  passwordCheckLength);
		 
		assertEquals("The password should not be empty", passwordCheckBlank);
		
	}

}
