package com.yash.tddexample;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class WordCounter {

	public Map<String, Integer> countNumberOfUniqueWord(String sentence, String delimter) {

		List<String> list = Stream.of(sentence).map(w -> w.split("\\s+")).flatMap(Arrays::stream)
				.collect(Collectors.toList());

		Map<String, Integer> wordCounter = list.stream()
				.collect(Collectors.toMap(w -> w, w -> 1, Integer::sum));

		System.out.println(wordCounter);
		return wordCounter;
	}

}
