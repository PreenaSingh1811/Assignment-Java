/*
 * package com.yash.tddexample;
 * 
 * 
 * 
 * import static org.hamcrest.CoreMatchers.containsString; import static
 * org.junit.Assert.assertEquals; import org.junit.After; import
 * org.junit.Before; import org.junit.Rule; import org.junit.Test; import
 * org.junit.rules.ExpectedException;
 * 
 * import com.yash.tddexample.*;
 * 
 * public class PasswordVerifierTest { PasswordVerifier passwordVerifier;
 * 
 * @Rule public ExpectedException runtiException = ExpectedException.none();
 * 
 * @Before public void initializePasswordVerifier() { passwordVerifier = new
 * PasswordVerifier(); }
 * 
 * @After public void destructPasswordVerifier() { passwordVerifier = null; }
 * 
 * @Test public void shouldVerifyPasswordEligibilityIfPasswordIsNull() {
 * runtiException.expect(RuntimeException.class);
 * runtiException.expectMessage(containsString(
 * "Password should have atleast one uppercase, one lowercase, one digit and have atleast 8 characters"
 * )); passwordVerifier.verify(null); }
 * 
 * @Test public void shouldVerifyPasswordEligibilityIfPasswordIsNotNull() {
 * runtiException.expect(RuntimeException.class);
 * runtiException.expectMessage(containsString(
 * "Password should have atleast one uppercase, one lowercase, one digit and have atleast 8 characters"
 * )); passwordVerifier.verify(""); }
 * 
 * @Test public void
 * shouldVerifyPasswordEligibilityIfPasswordIsNotNullAndHaveLowercaseLetter() {
 * runtiException.expect(RuntimeException.class);
 * runtiException.expectMessage(containsString(
 * "Password should have atleast one uppercase, one lowercase, one digit and have atleast 8 characters"
 * )); passwordVerifier.verify("a");
 * 
 * }
 * 
 * @Test public void
 * shouldVerifyPasswordEligibilityIfPasswordIsNotNullAndHaveUppercaseLetter() {
 * runtiException.expect(RuntimeException.class);
 * runtiException.expectMessage(containsString(
 * "Password should have atleast one uppercase, one lowercase, one digit and have atleast 8 characters"
 * )); passwordVerifier.verify("B");
 * 
 * }
 * 
 * @Test public void
 * shouldVerifyPasswordEligibilityIfPasswordIsNotNullAndHaveDigit() {
 * runtiException.expect(RuntimeException.class);
 * runtiException.expectMessage(containsString(
 * "Password should have atleast one uppercase, one lowercase, one digit and have atleast 8 characters"
 * )); passwordVerifier.verify("123");
 * 
 * }
 * 
 * @Test public void
 * shouldVerifyPasswordEligibilityIfPasswordIsNotNullAndHaveLowercaseLetterAndUppercaseLetter
 * () { runtiException.expect(RuntimeException.class);
 * runtiException.expectMessage(containsString(
 * "Password should have atleast one uppercase, one lowercase, one digit and have atleast 8 characters"
 * )); passwordVerifier.verify("aB");
 * 
 * }
 * 
 * @Test public void
 * shouldVerifyPasswordEligibilityIfPasswordIsNotNullAndHaveLowercaseLetterAndUppercaseLetterAndHaveDigit
 * () { String actual = passwordVerifier.verify("aB1"); String expected = "ok";
 * assertEquals(expected, actual); }
 * 
 * @Test public void
 * shouldVerifyPasswordEligibilityIfPasswordIsNotNullAndHaveLowercaseLetterAndUppercaseLetterAndHaveDigitAndLengthGreaterThanEight
 * () { String actual = passwordVerifier.verify("aB1acfsdDS"); String expected =
 * "ok"; assertEquals(expected, actual); }
 * 
 * }
 */