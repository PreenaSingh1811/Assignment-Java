package com.yash.tddexample;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class DivisibilityTest {

	@Test
	public void shouldPrintFizzIfNumberIsDivisibleByThree() {
		int number = 27;
		FizzBuzz obj = new FizzBuzz();
		String ans = obj.numberdivisibleByThree(number);
		assertEquals(ans, "Fizz");

	}

}
