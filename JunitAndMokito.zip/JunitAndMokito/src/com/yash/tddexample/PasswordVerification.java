package com.yash.tddexample;

import org.apache.commons.lang.StringUtils;

public class PasswordVerification {

	public String shouldVerifiyPasswordEligibility(String password) {

		if (!(StringUtils.isNotEmpty(password)) && !(password.chars().anyMatch(ch -> Character.isLowerCase(ch)))) {
			return "The password should not be empty and contain 1 lower case";
		} else {
			if (!(password.length() < 8) ){
				return "The password should not be less than 8 character";
			} else if (!(password.chars().anyMatch(ch -> Character.isUpperCase(ch)))) {
				return "Should contain 1 upper case";
			} else if (!(password.chars().anyMatch(ch -> Character.isLowerCase(ch)))) {
				return "Should contain 1 lower case";
			} else if (!(password.chars().anyMatch(ch -> Character.isDigit(ch)))) {
				return "Should contain 1 digit";
			} else {
				return "correct Password";

			}
		}

	}

}
