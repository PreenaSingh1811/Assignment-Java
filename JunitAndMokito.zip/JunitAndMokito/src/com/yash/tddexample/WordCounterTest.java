package com.yash.tddexample;

import static org.junit.Assert.assertEquals;

import java.util.HashMap;
import java.util.Map;

import org.junit.Test;

public class WordCounterTest {
	
	@Test
	public void shouldCountUniqueNumberOfWords() {
		WordCounter obj = new WordCounter();
		String sentence = "Boom Bang Boom";
		String delimter = " ";
		Map<String,Integer> actual=obj.countNumberOfUniqueWord(sentence,delimter);
		Map<String,Integer> expected= new HashMap<String, Integer>();
		expected.put("Boom", 2);
		expected.put("Bang", 1);
		assertEquals(expected, actual);

	}

}
